# Release readiness

**Status: scoped live Slack pilot verified. Public self-serve release is pending.** The source is committed in a local `agent-collaboration` repository. Registry and site changes were pushed to review branches and await deployment.

## Delivered

- Versioned event schema, provider-independent workspace and agent identity, local SQLite state, stable occurrence reconciliation, replay, permission-checked staging, revocation, durable delivery, retention and receipts.
- Platform-first local CLI with canonical profile/team selection, saved collections, explicit install planning, opt-in canonical installer wrapper, capability checks and a first no-effect conversation. Existing ecosystem and Kennel installation semantics are preserved. Full role/dependency installation still depends on each selected host's supported runtime and canonical installer.
- Signed Slack ingress and threaded delivery, Matrix sync and transaction-keyed thread replies, common connector SDK, a no-effect standalone host, and a General Commander coordination reference.
- Software Factory adapter for exact sealed converter preparation/submission and bounded native observation using the original control API. WebOps supports a read-only recorded-state projection. No execution-controller changes were required.
- Bounded Teams SDK activity/reply bridge, read-only Paperclip and Board observations, scoped Board SDK intake and reply, local read-only MCP stdio, and a documented custom host interface.
- Canonical profile-scoped compatibility metadata and generated agent-site displays for General Commander and the VideoOps Producer. Fixture-only rows create no active installation links.

## Acceptance status

| Scenario | Status | Evidence and limit |
|---|---|---|
| General Commander and VideoOps specialist in Slack | **Live private-channel pilot passed.** | Distinct Slack profiles and portraits, signed intake, real-model specialist handoff, review mention, same-thread human choice and one verified closing reply. Restart, live revocation and uninstall, and independent installation with unrelated apps still need qualification. |
| Matrix portability | **Offline fixture passed. Live blocked.** | Same canonical IDs, workspace, envelope and host contract with a separate transport. Matrix cursor, encryption refusal, thread/reply shape and gap behavior tested. No live homeserver was used. |
| Standalone first use | **Passed locally for the reference host.** | Interactive CLI verified without Factory. A real canonical `kujo agent new --profile basic --provider fixture --no-git` scaffold succeeded independently. Connecting an owned model-backed project or real registry-defined role runtime to the generic host is not qualified. |
| Chain of Command installation | **Registration and canonical dry-run passed.** | All 28 roles registered from the installed canonical checkout, stable selections and scoped revocation verified. Full canonical installer was invoked in dry-run mode only. No claim of installing individual role runtime tools, a clean-OS installation or automatically resolving grants. |
| Software Factory | **Native live Slack converter mission passed.** | Separate preparation and exact-digest submission ran GPT-5.6 Sol and five free Hermes calls through Dispatch. Workcell API and browser checks, Lens and the controller release gates produced an approved local candidate that appeared in Slack. The exported Factory evidence verified offline. |
| Vercel Board | **Local and hosted round trips passed.** | Board SDK 0.53.0 accepted a native root from a mapped principal. Two approved live advisory calls produced separate General Commander and Code Reviewer replies in the same hosted thread, with provider evidence, duplicate refusal and native sync disabled. Tested on the authorized General board. Task claims, wakeups, native sync and automated onboarding remain unqualified. |
| Teams, Paperclip, MCP | **Fixture or local only.** | Teams uses an operator-provided authenticated Teams SDK app and prebound conversation routes. Paperclip is read-only. MCP stdio exposes roster and delivery status. |
| Other factories | **Partial.** | WebOps state projection and existing regressions passed. VideoOps, Publishing House and Product Launch still need independently approved host adapters for delegated execution. |
| Website/platform onboarding | **Static agent pages built and validated.** | Profile-level compatibility is visible. Live OAuth, bot provisioning and a full public guided wizard are future work. Teams, Board and Paperclip setup actions are not advertised. No team-level connector setup has been qualified. |

Before releasing Slack to other operators, publish a versioned install source, validate the guide from a fresh authorized workspace, and qualify stable ingress, restart and recovery, revocation and uninstall alongside unrelated apps. Matrix live qualification remains separate. Verify exact provider and host versions. Obtain separate permission for any model-backed mission. Before a hosted distribution, qualify tenant isolation, credential storage, backup/restore, supervision and operational limits. [Security model](SECURITY.md) · [Installer audit](INSTALLER-AUDIT.md) · [Executed checks](qualification.json)

Primary integration sources consulted on 2026-11-20. [Slack Events](https://docs.slack.dev/apis/events-api/) · [Matrix client-server](https://spec.matrix.org/latest/client-server-api/) · [Teams App API](https://learn.microsoft.com/en-us/javascript/api/teams-sdk-typescript/%40microsoft/teams.apps/app) · [Paperclip Issues](https://docs.paperclip.ing/reference/api/issues/) · [Board source at b9ae9ea](https://github.com/vercel/board/tree/b9ae9eac224e91afd95d6d3f67d0ca034681d92a) · [MCP protocol](https://modelcontextprotocol.io/specification/2025-11-25)
