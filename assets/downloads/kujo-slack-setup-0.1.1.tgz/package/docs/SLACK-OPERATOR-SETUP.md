# Install a Kujo agent as a Slack bot

Use this guide for a self-hosted Slack pilot. The two-profile planning example
passed live in a private channel. The Collaboration checkout is still an
operator-managed preview. Workspace app approval, a reachable HTTPS endpoint
and a compatible agent host are prerequisites.

## 1. Choose the role and its host

Pick the canonical role from the Kujo Agents checkout. Match the role to a
supported host and its operations. The available reference paths are:

- **Connector smoke test.** Use `node bin/collaboration.mjs setup DB CATALOG`,
  select Slack and one eligible role, and enroll it for the no-effect fixture.
  Use the deployment ID from `roster DB WORKSPACE`. The fixture verifies
  messaging without model usage.
- **General Commander with Software Factory.** Enroll a Commander deployment
  using `bind-factory DB WORKSPACE DEPLOYMENT`. Follow the private control
  grant and exact-digest submission steps in the
  [Software Factory section](../README.md#software-factory).
- **General Commander and VideoOps Producer.** Use the
  [VideoOps advisory example](../README.md#slack-agent-identities). The
  Producer drafts a plan in text. Media production requires the full VideoOps
  host.

Register the local workspace and operator with `setup` if they do not exist.
Use Node 24 or later and an owner-only local state directory. A role page
and its portrait supply identity. The selected host supplies execution.

## 2. Create and install the Slack app

In [Slack app settings](https://api.slack.com/apps), choose **Create New App**
and use **Paste a manifest** or configure the app manually. Name it for the role
and add the role's portrait in **Basic Information**. Give its Slack bot
`chat:write`. For a bot that receives mentions, also grant `app_mentions:read`.
Install it to the authorized workspace and invite it to a dedicated channel.
Each additional separately mentionable role needs its own app and bot token.
The tested Producer is an outbound specialist. Commander is the inbound bot.

For a mention-receiving bot, this is the initial manifest. Change both names
to match your selected role. Add the callback later, when it is reachable.

```json
{
  "display_information": {
    "name": "General Commander",
    "description": "Coordinates Kujo agent work and brings in specialists."
  },
  "features": {
    "bot_user": {"display_name": "General Commander", "always_online": false}
  },
  "oauth_config": {
    "scopes": {"bot": ["app_mentions:read", "chat:write"]}
  },
  "settings": {"org_deploy_enabled": false, "socket_mode_enabled": false}
}
```

[Slack app setup](https://docs.slack.dev/app-management/quickstart-app-settings/) ·
[Slack manifests](https://docs.slack.dev/app-manifests/configuring-apps-with-app-manifests/)

## 3. Bind Slack to Kujo

Configure the owner-only connector process with `SLACK_APP_ID`,
`SLACK_TEAM_ID`, `SLACK_BOT_USER_ID`, and `SLACK_SIGNING_SECRET`. For one
bot, provide its `SLACK_BOT_TOKEN`. For separate bot senders, supply the
deployment-keyed `SLACK_AGENT_BOTS` map and, when a human reviewer should
receive a real tag, a channel-keyed `SLACK_REVIEW_USERS` map. Layouts are
documented in [Slack agent identities](../README.md#slack-agent-identities).
Find the app ID and signing secret in **Basic Information**, and the bot token
in **OAuth & Permissions**. Use Slack’s authenticated `auth.test` method to
identify the workspace and bot user. Copy the channel ID from channel details.
Keep tokens and signing secrets out of Slack messages, source and logs.

Run these commands from the Collaboration checkout with the actual IDs:

```sh
node bin/collaboration.mjs health slack
node bin/collaboration.mjs connection "$DB" "$WORKSPACE" slack "$CONNECTION" "$SLACK_TEAM_ID"
node bin/collaboration.mjs map "$DB" "$WORKSPACE" "$CONNECTION" "$SLACK_HUMAN_ID" "$OPERATOR"
node bin/collaboration.mjs room "$DB" "$WORKSPACE" "$CONNECTION" "$SLACK_CHANNEL_ID" "$DEPLOYMENT"
node bin/collaboration.mjs slack "$DB" "$WORKSPACE" "$CONNECTION" 4387
```

Point a trusted HTTPS proxy at the loopback connector. In the ingress app's
**Event Subscriptions**, set the verified Request URL ending in `/slack/events`,
subscribe to `app_mention` under bot events, and save. Keep the connector
running while testing. Use a stable URL for a pilot other people rely on.
[Slack Events API](https://docs.slack.dev/apis/events-api/) ·
[Slack signatures](https://docs.slack.dev/authentication/verifying-requests-from-slack/)

## 4. Verify a first interaction

From the mapped Slack account, mention the bot in the test channel and send
`request: <bounded test request>`. Use `replay DB WORKSPACE` to find the
staged event. For the fixture, use `accept-fixture DB WORKSPACE EVENT OPERATOR`.
For live work, follow the selected host’s admission and submission path above.
Check `deliveries DB WORKSPACE` and verify the reply and role portrait in the
original Slack thread. If a send is ambiguous, reconcile it against Slack
before attempting another send.

Follow [release readiness](RELEASE-READINESS.md) before advertising the setup
as self-serve. The first operator-run pilot and a fresh-workspace installation
by an independent administrator are separate checks.
