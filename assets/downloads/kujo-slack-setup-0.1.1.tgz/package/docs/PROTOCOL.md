# Protocol and adapter SDK

The collaboration package owns event envelopes, workspace bindings, staged requests and delivery receipts. Existing installers distribute canonical definitions. Each host owns models, task state, verification and approvals. Node's built-in SQLite and HTTPS APIs provide persistence and raw request authentication without a third-party dependency. The website remains a Kujo SSG build.

`createCollaboration({store, clock, retentionMs})` creates the trusted local library. Pass `sqlite(file)` from `src/store.mjs` for persistence. Alternate backends must currently implement the synchronous SQL and transaction boundary in that module. Operator and authenticated host code call the library directly. Actor IDs are trusted arguments at that local boundary.

- `workspace`, `human`, `agent/agents` and `connection` establish local bindings. `discover` lists active deployments, with definition ID separate from deployment ID. An operator can attest a namespaced third-party definition.
- `map`, `unmap`, `allowRoom`, `link` and `revoke` manage account, room and thread references. An operator explicitly links external roots when sharing a canonical thread across connectors.
- `post` appends a local event. `inbound` accepts a verified transport envelope. Exact occurrence retries return a local duplicate acknowledgement. Conflicting duplicates fail. Event and delivery intents commit together. See the [event schema](../schemas/event.v1.json).
- `admit` rechecks current operator, initiator, target and bindings, then persists uncertainty before handing off to the host. The resulting receipt records adapter acceptance. `approval.request` is informational. V1 has no approval response.
- `replay` returns bounded pages through a monotonic local cursor. `deliveries` and `recoverDeliveries` expose queue state. Known safe refusals, such as rate limits, are retried at most five times. Stale sending leases become ambiguous. Uncertain provider writes are never automatically redriven.
- `prune` removes retained events and delivery rows at the configured horizon, 30 days by default. Schedule it under the operator account. Dedupe lasts for retained events. Provider edits, deletions and retention are separate.

## Host adapters

Supply `schema: HOST`, a stable `id`, supported `operations` and `async accept({event, deployment})`. Verify deployment ownership and exact effect scope independently. Return `{state:'accepted'|'declined'|'uncertain',ref?}` for your durable native request. Use `event.id` for native idempotency. Publish bounded observations through an authenticated local `post` call. The host owns execution cancellation and cleanup.

General Commander reference functions discover eligible specialists and stage a one-hop request linked to a human parent. A separate operator action admits the specialist request. Use the canonical catalog and `plan` to explain missing capabilities. An available profile does not grant execution or installation rights.

## Transport adapters

Supply `schema: TRANSPORT`, `platform`, `externalAccount` and `async send({deliveryId, room, root, event})` returning `{state:'sent'|'retry'|'dead'|'ambiguous',ref?,retryMs?}`. Authenticate ingress, use stable provider occurrence IDs, and preserve exact room/thread identities. Supply a scoped identity health check. Use short timeouts, prevent credential redirects and return retry only when repetition is safe. Reject unknown contract major versions. Native host schemas remain distinct and are linked by opaque receipt references and digests.
