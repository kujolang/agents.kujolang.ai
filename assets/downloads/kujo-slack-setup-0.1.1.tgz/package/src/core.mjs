import {randomUUID} from 'node:crypto';
import {content, digest, HOST, id, PROTOCOL, REQUESTS, requireValue, TRANSPORT} from './protocol.mjs';
import {sqlite} from './store.mjs';

const LOOKUP = 'SELECT value FROM entity WHERE kind=? AND scope=? AND id=?';
const decode = row => row && JSON.parse(row.value);
const enabled = record => record && !record.revoked;
const actorKey = ({kind, id: actorId}) => `${kind}:${id(actorId)}`;

export function createCollaboration({
  store = sqlite(), clock = Date.now, retentionMs = 30 * 86400_000,
} = {}) {
  requireValue(Number.isSafeInteger(retentionMs) && retentionMs >= 86400_000 && retentionMs <= 90 * 86400_000, 'invalid-retention');
  const get = (kind, scope, key) => decode(store.get(LOOKUP, kind, scope, key));
  const list = (kind, scope) => store.all('SELECT value FROM entity WHERE kind=? AND scope=? ORDER BY id LIMIT 1000', kind, scope).map(decode);
  const put = (kind, scope, key, value) => store.run(
    'INSERT INTO entity VALUES (?,?,?,?) ON CONFLICT(kind,scope,id) DO UPDATE SET value=excluded.value',
    kind, scope, key, JSON.stringify(value),
  );
  function saveLimited(kind, scope, key, value) {
    requireValue(get(kind, scope, id(key)) || list(kind, scope).length < 1000, 'resource-limit');
    put(kind, scope, key, value);
    return value;
  }
  const save = (...args) => store.transaction(() => saveLimited(...args));
  const workspace = ws => requireValue(enabled(get('workspace', '', id(ws))), 'unknown-workspace');
  function actor(ws, value) {
    requireValue(value && ['human', 'agent'].includes(value.kind), 'invalid-actor');
    const current = get(value.kind, ws, id(value.id));
    requireValue(enabled(current), 'actor-not-enrolled');
    return current;
  }
  function getConnection(ws, connection) {
    const value = get('connection', ws, id(connection));
    requireValue(enabled(value), 'connection-unavailable');
    return value;
  }
  const findEvent = (ws, key) => decode(store.get('SELECT value FROM event WHERE workspace=? AND id=?', ws, id(key)));

  function enroll(workspaceId, kind, value) {
    workspace(workspaceId);
    const key = id(value.id);
    const old = get(kind, workspaceId, key);
    requireValue(!old?.revoked, 'binding-revoked');
    if (old && kind === 'agent') {
      requireValue(!old.revoked && old.definitionId === value.definitionId && old.hostId === value.hostId, 'deployment-conflict');
    }
    if (kind === 'connection') {
      requireValue(key.length <= 100, 'invalid-connection-id');
    }
    if (old && kind === 'connection') {
      requireValue(!old.revoked && old.platform === value.platform && old.externalAccount === value.externalAccount, 'connection-conflict');
    }
    return saveLimited(kind, workspaceId, key, value);
  }

  function enrollAgent(ws, agent) {
    const {id: key, definitionId, hostId, capabilities = [], operations = []} = agent;
    requireValue(Array.isArray(capabilities) && Array.isArray(operations) && capabilities.length <= 32
      && operations.every(op => REQUESTS.includes(op)), 'invalid-capabilities');
    return enroll(ws, 'agent', {id: id(key), definitionId: id(definitionId), hostId: id(hostId),
      capabilities: [...new Set(capabilities.map(id))], operations: [...new Set(operations)]});
  }

  function append(workspaceId, threadId, rawActor, input, origin) {
    workspace(workspaceId);
    id(threadId);
    id(origin.source);
    id(origin.occurrence);
    const principal = actor(workspaceId, rawActor);
    const data = content(input);
    const hash = digest([threadId, actorKey(rawActor), data]);
    const old = store.get('SELECT hash,value FROM event WHERE workspace=? AND source=? AND occurrence=?',
      workspaceId, origin.source, origin.occurrence);
    if (old) {
      requireValue(old.hash === hash, 'occurrence-conflict');
      return {duplicate: true, event: decode(old)};
    }
    if (data.target) actor(workspaceId, {kind: 'agent', id: data.target});
    for (const mention of data.mentions) actor(workspaceId, {kind: 'agent', id: mention});
    if (data.replyTo) requireValue(findEvent(workspaceId, data.replyTo)?.threadId === threadId, 'unknown-reply');
    const parent = data.cause && findEvent(workspaceId, data.cause);
    if (data.cause) requireValue(parent?.threadId === threadId, 'unknown-cause');
    if (REQUESTS.includes(data.type)) {
      requireValue(data.target, 'missing-target');
      requireValue(principal.operations.includes(data.type), 'request-forbidden');
      const target = actor(workspaceId, {kind: 'agent', id: data.target});
      requireValue(target.capabilities.includes(data.type), 'missing-capability');
      if (rawActor.kind === 'agent') {
        // One agent hop from an admitted human request addressed to that agent.
        requireValue(parent?.actor.kind === 'human' && parent.data.target === principal.id
          && REQUESTS.includes(parent.data.type) && get('request', workspaceId, parent.id)?.state === 'accepted'
          && data.target !== principal.id
          && !get('delegated', workspaceId, parent.id), 'delegation-forbidden');
        put('delegated', workspaceId, parent.id, {created: clock()});
      }
    }
    if (rawActor.kind === 'human') {
      requireValue(data.type === 'message' || REQUESTS.includes(data.type), 'observation-forbidden');
      requireValue(data.evidence.length === 0, 'evidence-forbidden');
    }
    requireValue(store.get('SELECT count(*) AS n FROM event WHERE workspace=?', workspaceId).n < 10000, 'journal-full');
    const now = clock();
    const event = {schema: PROTOCOL, id: randomUUID(), workspaceId, threadId,
      actor: {kind: rawActor.kind, id: principal.id, ...(principal.definitionId ? {definitionId: principal.definitionId} : {})},
      origin, correlationId: parent?.correlationId ?? randomUUID(),
      recordedAt: new Date(now).toISOString(), data};
    const cursor = store.run('INSERT INTO event(workspace,thread,id,source,occurrence,hash,created,value) VALUES (?,?,?,?,?,?,?,?)',
      workspaceId, threadId, event.id, origin.source, origin.occurrence, hash, now, '{}').lastInsertRowid;
    event.cursor = Number(cursor);
    store.run('UPDATE event SET value=? WHERE id=?', JSON.stringify(event), event.id);
    if (REQUESTS.includes(data.type)) put('request', workspaceId, event.id, {state: 'staged', created: now});
    const publish = ['message', 'status', 'execution.observation', 'approval.request'].includes(data.type)
      && rawActor.kind === 'agent';
    if (publish) {
      const destinations = list('link', workspaceId).filter(link => link.threadId === threadId
        && link.publish && link.connection !== origin.connection && enabled(get('connection',workspaceId,link.connection)));
      requireValue(destinations.length <= 16, 'too-many-destinations');
      for (const link of destinations) {
        const count = store.get("SELECT count(*) AS n FROM delivery WHERE workspace=? AND state IN ('pending','sending','ambiguous')", workspaceId).n;
        requireValue(count < 1000, 'queue-full');
        store.run('INSERT INTO delivery(id,workspace,connection,eventId,thread,state,due) VALUES (?,?,?,?,?,?,?)',
          digest([event.id, link.id]), workspaceId, link.connection, event.id, link.id, 'pending', now);
      }
    }
    return {duplicate: false, event};
  }

  function inbound(workspaceId, connectionId, input) {
    return store.transaction(() => {
      const connection = getConnection(workspaceId, connectionId);
      requireValue(input.account === connection.externalAccount && input.platform === connection.platform, 'account-mismatch');
      if (input.ignore) return {ignored: true};
      const linkKey = digest([connectionId, id(input.room), id(input.root)]);
      let link = get('link', workspaceId, linkKey);
      const roomPolicy = get('room', workspaceId, digest([connectionId, input.room]));
      requireValue(link || roomPolicy, 'conversation-not-linked');
      const mappingKey = digest([connectionId, id(input.subject)]);
    const mapping = get('mapping', workspaceId, mappingKey);
      requireValue(enabled(mapping), 'unmapped-subject');
      if (!link) {
        requireValue(list('link', workspaceId).length < 1000, 'resource-limit');
        link = {id:linkKey, connection:connectionId, room:input.room, root:input.root,
          threadId:randomUUID(), defaultAgent:roomPolicy.defaultAgent, publish:roomPolicy.publish};
        put('link', workspaceId, linkKey, link);
      }
      const target = input.target ?? link.defaultAgent;
      return append(workspaceId, link.threadId, {kind: 'human', id: mapping.human},
        {type: input.type, text: input.text, target, mentions: target ? [target] : []},
        {source: `connection:${connectionId}`, occurrence: id(input.occurrence), connection: connectionId, mappingKey, mappingRevision:mapping.revision});
    });
  }

  function takeDelivery(ws, connection, transport) {
    return store.transaction(() => {
      const installed = getConnection(ws, connection);
      requireValue(transport.platform === installed.platform && transport.externalAccount === installed.externalAccount,
        'incompatible-transport');
      const row = store.get("SELECT delivery.* FROM delivery JOIN event ON event.id=delivery.eventId WHERE delivery.workspace=? AND connection=? AND state='pending' AND due<=? ORDER BY due,event.seq,delivery.id LIMIT 1",
        ws, connection, clock());
      if (!row) return null;
      const event = findEvent(ws, row.eventId);
      const link = get('link', ws, row.thread);
      const sender = event && get(event.actor.kind, ws, event.actor.id);
      if (!link?.publish || link.threadId !== event?.threadId || !enabled(sender)) {
        store.run("UPDATE delivery SET state='suppressed',result='scope-revoked' WHERE id=?", row.id);
        return {suppressed: true};
      }
      store.run("UPDATE delivery SET state='sending',attempts=attempts+1,due=? WHERE id=?", clock() + 120_000, row.id);
      return {row, event, link};
    });
  }

  async function deliver(ws, connection, transport) {
    requireValue(transport?.schema === TRANSPORT, 'incompatible-transport');
    const item = takeDelivery(ws, connection, transport);
    if (!item || item.suppressed) return item;
    const {row, event, link} = item;
    let outcome;
    try {
      outcome = await transport.send({deliveryId: row.id, ...link, event});
    } catch {
      outcome = {state: 'ambiguous'};
    }
    const state = ['sent', 'retry', 'dead', 'ambiguous'].includes(outcome?.state) ? outcome.state : 'ambiguous';
    // Honor provider delays. Delays over an hour are terminal for this bounded queue.
    const delay = Number(outcome?.retryMs) || 0;
    const retry = Math.max(2 ** row.attempts * 1000, delay);
    const final = state === 'retry' ? (row.attempts < 4 && retry <= 3600_000 ? 'pending' : 'dead') : state;
    const receipt = typeof outcome?.ref === 'string' && /^[\w.:@$!+=/~-]{1,200}$/.test(outcome.ref) ? outcome.ref : null;
    const settled = store.run("UPDATE delivery SET state=?,result=?,due=? WHERE id=? AND state='sending'",
      final, receipt, clock() + (final === 'pending' ? retry : 0), row.id);
    return {deliveryId:row.id, state:settled.changes ? final : 'ambiguous', ref:settled.changes ? receipt : null};
  }

  function requestActor(ws, event) {
    const requester = actor(ws, event.actor);
    requireValue(requester.operations.includes(event.data.type), 'request-forbidden');
    if (event.origin.connection) {
      getConnection(ws, event.origin.connection);
      const mapping = get('mapping', ws, event.origin.mappingKey);
      requireValue(mapping?.human === requester.id && mapping.revision === event.origin.mappingRevision, 'mapping-revoked');
    }
    return requester;
  }

  function authorizeStagedRequest(ws, eventId, operator) {
    workspace(ws);
    const reviewer = actor(ws, {kind:'human',id:operator});
    requireValue(reviewer.operations.includes('admit'), 'admit-forbidden');
    const event = findEvent(ws, eventId);
    const record = get('request', ws, eventId);
    requireValue(event && record?.state === 'staged', 'request-unavailable');
    requestActor(ws, event);
    const target = actor(ws, {kind:'agent',id:event.data.target});
    requireValue(target.capabilities.includes(event.data.type), 'incompatible-host');
    return {event, target, record};
  }

  function authorizedRequest(ws, eventId, operator, host) {
    return store.transaction(() => {
      const admission = authorizeStagedRequest(ws, eventId, operator);
      requireValue(host?.schema === HOST && host.id === admission.target.hostId
        && host.operations?.includes(admission.event.data.type), 'incompatible-host');
      put('request', ws, eventId, {...admission.record, state:'uncertain', operator});
      return admission;
    });
  }

  return {
    close: () => store.close(),
    workspace: ws => save('workspace', '', ws, {id:ws}),
    human: (ws, humanId, operations = []) => {
      requireValue(Array.isArray(operations) && operations.every(op => [...REQUESTS,'admit'].includes(op)), 'invalid-operations');
      return store.transaction(() => enroll(ws, 'human', {id:id(humanId), operations:[...new Set(operations)]}));
    },
    agent: (ws, value) => store.transaction(() => enrollAgent(ws, value)),
    agents(ws, values) {
      requireValue(Array.isArray(values) && values.length <= 500, 'invalid-selection');
      return store.transaction(() => values.map(value => enrollAgent(ws, value)));
    },
    collection(ws, name, ids) {
      workspace(ws);
      requireValue(Array.isArray(ids) && ids.length > 0 && ids.length <= 100, 'invalid-collection');
      for (const key of ids) actor(ws, {kind:'agent',id:key});
      return save('collection', ws, id(name), {id:name,deployments:[...new Set(ids)]});
    },
    collections(ws) {
      workspace(ws);
      return list('collection', ws).map(collection => ({...collection,
        deployments:collection.deployments.filter(key => enabled(get('agent',ws,key)))}));
    },
    discover(ws) { workspace(ws); return list('agent', ws).filter(enabled); },
    connection: (ws, value) => store.transaction(() => enroll(ws, 'connection', {id:id(value.id),
      platform:id(value.platform), externalAccount:id(value.externalAccount)})),
    map(ws, connection, subject, human) {
      getConnection(ws, connection);
      actor(ws, {kind: 'human', id: human});
      const key = digest([connection, id(subject)]);
      return store.transaction(() => {
        const current = get('mapping', ws, key);
        return current?.human === human ? current : saveLimited('mapping', ws, key, {human, revision:randomUUID()});
      });
    },
    unmap(ws, connection, subject) {
      getConnection(ws, connection);
      return store.run("DELETE FROM entity WHERE kind='mapping' AND scope=? AND id=?", ws, digest([connection, id(subject)])).changes;
    },
    link(ws, {connection, room, root, threadId, defaultAgent, publish = false}) {
      getConnection(ws, connection);
      if (defaultAgent) actor(ws, {kind:'agent',id:defaultAgent});
      const key = digest([connection, id(room), id(root)]);
      return save('link', ws, key, {id:key, connection, room, root, threadId:id(threadId), defaultAgent, publish:publish === true});
    },
    revoke(ws, kind, key) {
      workspace(ws);
      requireValue(['agent','human','connection'].includes(kind), 'unsupported-operation');
      return store.transaction(() => {
        const value = get(kind, ws, id(key));
        requireValue(value, 'unknown-binding');
        return saveLimited(kind, ws, key, {...value, revoked:true});
      });
    },
    allowRoom(ws, {connection, room, defaultAgent, publish = false}) {
      getConnection(ws, connection);
      if (defaultAgent) actor(ws, {kind:'agent',id:defaultAgent});
      return save('room', ws, digest([connection, id(room)]), {defaultAgent, publish:publish === true});
    },
    checkConnection(ws, connection, transport) {
      const binding = getConnection(ws, connection);
      requireValue(transport.platform === binding.platform && transport.externalAccount === binding.externalAccount,
        'incompatible-transport');
    },
    checkpoint(ws, connection, token) {
      const binding = getConnection(ws, connection);
      requireValue(binding.platform === 'matrix', 'unsupported-operation');
      if (token === undefined) return get('cursor', ws, connection)?.token;
      requireValue(typeof token === 'string' && token.length <= 4096 && token.length > 0, 'invalid-cursor');
      return save('cursor', ws, connection, {token});
    },
    inbound,
    post(ws, thread, principal, input, occurrence) {
      return store.transaction(() => append(ws, thread, principal, input,
        {source: actorKey(principal), occurrence: id(occurrence)}));
    },
    replay(ws, {after = 0, limit = 100, thread} = {}) {
      workspace(ws);
      requireValue(Number.isSafeInteger(after) && after >= 0 && Number.isInteger(limit)
        && limit > 0 && limit <= 250, 'invalid-cursor');
      return (thread ? store.all('SELECT value FROM event WHERE workspace=? AND seq>? AND thread=? ORDER BY seq LIMIT ?', ws, after, id(thread), limit)
        : store.all('SELECT value FROM event WHERE workspace=? AND seq>? ORDER BY seq LIMIT ?', ws, after, limit)).map(decode);
    },
    deliver,
    deliveries(ws, eventId) {
      workspace(ws);
      const columns = 'SELECT id,state,attempts,due,result FROM delivery WHERE workspace=?';
      const tail = ' ORDER BY due,id LIMIT 250';
      return eventId === undefined ? store.all(columns+tail,ws)
        : store.all(columns+' AND eventId=?'+tail,ws,id(eventId));
    },
    recoverDeliveries(ws) {
      workspace(ws);
      return store.run("UPDATE delivery SET state='ambiguous' WHERE workspace=? AND state='sending' AND due<=?", ws, clock()).changes;
    },
    prune(ws) {
      workspace(ws);
      return store.transaction(() => {
        const cutoff = clock() - retentionMs;
        const result = store.run('DELETE FROM event WHERE workspace=? AND created<?', ws, cutoff);
        store.run("DELETE FROM entity WHERE scope=? AND kind IN ('request','delegated','closed-review','connector-check') AND json_extract(value,'$.created')<?", ws, cutoff);
        return result.changes;
      });
    },
    event(ws, key) { workspace(ws); const event = findEvent(ws, key); requireValue(event, 'unknown-event'); return event; },
    request(ws, key) { workspace(ws); return get('request', ws, id(key)); },
    acceptedRequest(ws, eventId, operator) {
      workspace(ws);
      requireValue(actor(ws, {kind:'human',id:operator}).operations.includes('admit'), 'admit-forbidden');
      const event = findEvent(ws,eventId);
      const record = get('request',ws,eventId);
      requireValue(event && record?.operator === operator && record?.state === 'accepted' && record.ref, 'request-unavailable');
      requestActor(ws,event);
      return {event, ref:record.ref, deployment:actor(ws,{kind:'agent',id:event.data.target})};
    },
    recordTransportCheck(ws, {eventId, operator, connection, challenge}) {
      return store.transaction(() => {
        const {event, target, record} = authorizeStagedRequest(ws,eventId,operator);
        requireValue(event.origin.connection===connection && event.actor.id===operator
          && event.actor.kind==='human' && event.data.type==='task.request'
          && /^verify-[a-f0-9]{8}$/.test(challenge) && event.data.text===challenge,'invalid-transport-check');
        const reference = digest([connection,challenge]);
        requireValue(!get('connector-check',ws,reference),'transport-check-complete');
        const principal = {kind:'agent',id:target.id};
        const check = append(ws,event.threadId,principal,{
          type:'execution.observation',cause:event.id,
          text:'Slack setup verified. I received your mention and can reply in this thread.',
          evidence:[{kind:'connector-check',ref:reference,sha256:digest(event)}],
        },{source:actorKey(principal),occurrence:event.id}).event;
        put('connector-check',ws,reference,{created:clock(),eventId:check.id});
        put('request',ws,event.id,{...record,operator,state:'accepted',ref:check.id});
        return check;
      });
    },
    completeAdvisoryReview(ws, {reviewId, proposalId, responseId, operator, expectedReply}) {
      return store.transaction(() => {
        const {event:response, target, record} = authorizeStagedRequest(ws, responseId, operator);
        const review = findEvent(ws, reviewId);
        const proposal = findEvent(ws, proposalId);
        const handoff = review?.data.cause && findEvent(ws, review.data.cause);
        const root = handoff?.data.cause && findEvent(ws, handoff.data.cause);
        requireValue(response.data.type === 'task.request' && response.actor.kind === 'human'
          && review?.actor.kind === 'agent' && review.actor.id === target.id
          && review.data.type === 'approval.request' && review.threadId === response.threadId
          && review.cursor < response.cursor && handoff?.data.type === 'delegation.request'
          && handoff.actor.id === target.id && get('request',ws,handoff.id)?.state === 'accepted'
          && proposal?.actor.kind === 'agent' && proposal.actor.id === handoff.data.target
          && proposal.data.type === 'execution.observation' && proposal.data.cause === handoff.id
          && root?.actor.kind === 'human' && root.actor.id === response.actor.id
          && root.data.target === target.id && get('request',ws,root.id)?.state === 'accepted'
          && root.origin.connection === response.origin.connection, 'invalid-advisory-review');
        requestActor(ws,root);
        requireValue(typeof expectedReply === 'string' && expectedReply.length <= 250
          && response.data.text === expectedReply, 'review-reply-mismatch');
        requireValue(!get('closed-review',ws,reviewId), 'review-already-closed');

        const event = append(ws,response.threadId,{kind:'agent',id:target.id},{
          type:'execution.observation',cause:review.id,replyTo:response.id,
          text:'Planning review complete. '+expectedReply+'\nThe specialist’s plan above is finalized for this brief.',
          evidence:proposal.data.evidence,
        },{source:actorKey(review.actor),occurrence:digest(['advisory-review',review.id])}).event;
        put('request',ws,responseId,{...record,operator,state:'accepted',ref:event.id});
        put('closed-review',ws,reviewId,{created:clock(),eventId:event.id});
        return event;
      });
    },
    async admit(ws, eventId, operator, host) {
      const {event, target, record} = authorizedRequest(ws, eventId, operator, host);
      const outcome = await host.accept({event, deployment:target});
      requireValue(outcome && ['accepted','declined','uncertain'].includes(outcome.state), 'invalid-host-acknowledgement');
      const next = {...record, operator, state:outcome.state,
        ...(outcome.ref === undefined ? {} : {ref:id(outcome.ref)})};
      return save('request', ws, eventId, next);
    },
  };
}
