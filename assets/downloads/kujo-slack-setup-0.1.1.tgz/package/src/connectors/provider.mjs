import {requireValue} from '../protocol.mjs';

export function credential(token) {
  requireValue(typeof token === 'string' && token.length >= 8 && token.length <= 4096
    && !/[\s\u0000-\u001f]/u.test(token), 'missing-credential');
  return token;
}

export function plainText(event) {
  const label = event.actor.definitionId ?? event.actor.id;
  return `[${label}] ${event.data.text}`;
}

export async function jsonResponse(response, maxBytes = 2_000_000) {
  const reader = response.body?.getReader();
  requireValue(reader, 'invalid-provider-response');
  const parts = [];
  let length = 0;
  try {
    for (;;) {
      const {done, value} = await reader.read();
      if (done) break;
      length += value.length;
      requireValue(length <= maxBytes, 'provider-response-limit');
      parts.push(value);
    }
  } finally {
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
  return JSON.parse(Buffer.concat(parts).toString('utf8'));
}

export function retryAfter(response) {
  const seconds = Number(response.headers.get('Retry-After'));
  return {state:'retry', retryMs:Math.max(1000, (seconds || 1) * 1000)};
}
