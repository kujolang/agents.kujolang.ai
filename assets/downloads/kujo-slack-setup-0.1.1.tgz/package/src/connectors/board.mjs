import {id, requireValue, TRANSPORT} from '../protocol.mjs';
import {plainText} from './provider.mjs';

// The operator supplies a scoped SDK client and the specific threads to import.
export function boardTransport({board, account, threads, requestPrincipals, agents = {}}) {
  requireValue(typeof board?.thread === 'function' && typeof board.reply === 'function'
    && typeof board.as === 'function', 'board-sdk-required');
  const externalAccount = id(account);
  const rooms = new Map(Object.entries(threads).map(([root, room]) => [id(root), id(room)]));
  const principals = new Set(requestPrincipals.map(id));
  const names = new Map(Object.entries(agents).map(([deployment, name]) => [id(deployment), id(name)]));

  async function readRoot(root) {
    const room = rooms.get(id(root));
    requireValue(room, 'thread-not-linked');
    const {message} = await board.thread(root, {limit:1});
    requireValue(message?.id === root && message.channel === room
      && message.re === null && !message.deleted, 'invalid-board-root');
    return message;
  }

  return {
    schema:TRANSPORT, platform:'board', externalAccount,
    async request(root) {
      const message = await readRoot(root);
      const subject = message.by?.principal;
      requireValue(principals.has(subject) && message.by.profile === null && !message.origin,
        'unmapped-board-author');
      requireValue(typeof message.text === 'string' && message.text.startsWith('request: '),
        'invalid-board-request');
      return {platform:'board', account:externalAccount, occurrence:root, subject,
        room:message.channel, root, type:'task.request', text:message.text.slice(9)};
    },
    async send({deliveryId, room, root, event}) {
      const name = names.get(event.actor.id);
      if (rooms.get(root) !== room || event.actor.kind !== 'agent' || !name) return {state:'dead'};
      const reply = await board.as({name}).reply(root, {
        text:plainText(event).replaceAll('@','＠'), noSync:true, id:id(deliveryId),
      });
      return {state:'sent',ref:id(reply.id)};
    },
  };
}
