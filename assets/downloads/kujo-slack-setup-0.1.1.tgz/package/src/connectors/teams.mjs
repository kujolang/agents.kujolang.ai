import {digest, id, requireValue, TRANSPORT} from '../protocol.mjs';
import {plainText} from './provider.mjs';

export function teamsRoom(conversationId) {
  requireValue(typeof conversationId === 'string' && conversationId.length <= 512 && conversationId.length > 0, 'invalid-conversation');
  return digest([conversationId]);
}

// Call only from the Teams SDK's authenticated message handler. There is no
// public HTTP handler in this adapter, and no service URL from message data is used.
export function teamsEnvelope(activity, tenantId, botAccount) {
  requireValue(activity.channelId === 'msteams' && activity.conversation?.tenantId === tenantId
    && activity.recipient?.id === botAccount, 'account-mismatch');
  if (activity.type !== 'message' || activity.from?.id === botAccount
      || activity.from?.role === 'bot' || typeof activity.text !== 'string') return null;
  return {platform:'teams', account:id(tenantId), occurrence:id(activity.id),
    subject:id(activity.from?.aadObjectId), room:teamsRoom(activity.conversation.id),
    root:id(activity.replyToId ?? activity.id), type:'message', text:activity.text};
}

export function teamsTransport({app, routes, tenantId}) {
  requireValue(typeof app?.reply === 'function' && routes instanceof Map && id(tenantId), 'teams-sdk-required');
  return {
    schema:TRANSPORT, platform:'teams', externalAccount:tenantId,
    async send({room, root, event}) {
      const conversation = routes.get(room);
      if (!conversation || teamsRoom(conversation) !== room) return {state:'dead'};
      const result = await app.reply(conversation, id(root), {
        type:'message', text:plainText(event), textFormat:'plain',
      });
      return {state:'sent', ref:id(result.id)};
    },
  };
}
