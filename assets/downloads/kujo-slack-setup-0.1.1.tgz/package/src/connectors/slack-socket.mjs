import {Rejected, id, requireValue} from '../protocol.mjs';
import {credential, jsonResponse} from './provider.mjs';
import {slackEvent} from './slack.mjs';

export async function slackBotIdentity(token, fetcher = fetch) {
  const response = await fetcher('https://slack.com/api/auth.test',{
    method:'POST',headers:{authorization:'Bearer '+credential(token)},redirect:'error',signal:AbortSignal.timeout(10000),
  });
  const value = response.ok ? await jsonResponse(response,16_384) : {};
  requireValue(value.ok === true && /^B[A-Z0-9]+$/.test(value.bot_id ?? '')
    && /^T[A-Z0-9]+$/.test(value.team_id ?? '') && /^U[A-Z0-9]+$/.test(value.user_id ?? '')
    && !value.is_enterprise_install, 'bot-token-invalid');
  return {teamId:value.team_id,botUserId:value.user_id};
}

export async function openSlackSocket({appToken, config, onEvent, onStatus, fetcher = fetch, Socket = WebSocket}) {
  requireValue(/^xapp-[A-Za-z0-9-]+$/.test(appToken ?? ''), 'app-token-invalid');
  const response = await fetcher('https://slack.com/api/apps.connections.open',{
    method:'POST',headers:{authorization:'Bearer '+credential(appToken)},redirect:'error',signal:AbortSignal.timeout(10000),
  });
  const link = response.ok ? await jsonResponse(response,16_384) : {};
  requireValue(link.ok === true && typeof link.url === 'string', 'socket-access-failed');
  const url = new URL(link.url);
  requireValue(url.protocol==='wss:' && /^wss-[a-z0-9-]+\.slack\.com$/.test(url.hostname)
    && !url.username && !url.password && !url.port && url.pathname==='/link/', 'socket-url-rejected');
  const socket = new Socket(url.href);
  let connected = false, closing = false;
  const timeout = setTimeout(()=>stop('connection-timeout'),10_000);
  function stop(status) {
    if (closing) return;
    closing = true;
    clearTimeout(timeout);
    onStatus(status);
    socket.close();
  }
  socket.addEventListener('message', ({data})=>{
    if (closing) return;
    try {
      requireValue(typeof data === 'string' && Buffer.byteLength(data)<=131_072, 'socket-envelope-invalid');
      const packet = JSON.parse(data);
      if (packet.type === 'hello') {
        requireValue(packet.connection_info?.app_id === config.appId,'account-mismatch');
        clearTimeout(timeout);
        connected = true;
        return onStatus('connected');
      }
      if (packet.type === 'disconnect') return stop('reconnecting');
      requireValue(connected,'socket-not-ready');
      const ack = id(packet.envelope_id);
      if (packet.type === 'events_api') {
        try {
          const input = slackEvent(packet.payload, config);
          if (!input.ignored) onEvent(input);
        } catch (error) {
          if (!(error instanceof Rejected) || ['journal-full','queue-full','resource-limit','account-mismatch','connection-unavailable'].includes(error.code)) throw error;
        }
      }
      socket.send(JSON.stringify({envelope_id:ack}));
    } catch {
      stop('event-rejected');
    }
  });
  socket.addEventListener('close',()=>stop('reconnecting'));
  socket.addEventListener('error',()=>stop('reconnecting'));
  return () => stop('stopped');
}
export function slackSetupManifest(role) {
  requireValue(typeof role?.name==='string' && role.name.length>0 && role.name.length<=35,'unavailable-slack-profile');
  return {
    display_information:{name:role.name,description:`${role.name} from the Kujo agent catalog.`},
    features:{bot_user:{display_name:role.name,always_online:false}},
    oauth_config:{scopes:{bot:['app_mentions:read','chat:write']}},
    settings:{socket_mode_enabled:true,event_subscriptions:{bot_events:['app_mention']}},
  };
}
