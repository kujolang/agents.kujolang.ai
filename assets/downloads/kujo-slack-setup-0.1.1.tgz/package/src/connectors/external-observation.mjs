import {digest, id, requireValue} from '../protocol.mjs';
import {credential, jsonResponse} from './provider.mjs';

// Read only. Comments, checkout and wakeups have native Paperclip effects.
export function paperclipObserver({origin, token, companyId, issueIds, fetcher = fetch}) {
  const base = new URL(origin);
  credential(token);
  requireValue(base.protocol === 'https:' && !base.username && !base.password && base.pathname === '/'
    && !base.search && !base.hash, 'invalid-paperclip-origin');
  const company = id(companyId);
  const allowed = new Set(issueIds.map(id));
  return async issueId => {
    requireValue(allowed.has(issueId), 'issue-not-linked');
    const response = await fetcher(new URL('/api/issues/' + encodeURIComponent(issueId),base), {
      headers:{authorization:`Bearer ${token}`},redirect:'error',signal:AbortSignal.timeout(10000),
    });
    requireValue(response.ok, 'paperclip-observation-failed');
    const issue = await jsonResponse(response, 256_000);
    requireValue(issue.id === issueId && issue.companyId === company, 'account-mismatch');
    const ref = {id:issueId,status:id(issue.status)};
    return {type:'execution.observation',text:'Paperclip issue status: ' + ref.status,
      evidence:[{kind:'paperclip-issue-observation',ref:issueId,sha256:digest(ref)}]};
  };
}

// Accept a Board SDK handle constructed by an operator with read-only rights.
export function boardObserver({board, threadIds}) {
  requireValue(typeof board?.thread === 'function', 'board-sdk-required');
  const allowed = new Set(threadIds.map(id));
  return async threadId => {
    requireValue(allowed.has(threadId), 'thread-not-linked');
    const {message, replies} = await board.thread(threadId, {limit:20});
    requireValue(message?.id === threadId && Array.isArray(replies) && replies.length <= 20, 'invalid-board-observation');
    const ref = {id:threadId,observedReplies:replies.length};
    return {type:'execution.observation',text:`Board thread observed with ${ref.observedReplies} replies on this page.`,
      evidence:[{kind:'board-thread-observation',ref:threadId,sha256:digest(ref)}]};
  };
}
