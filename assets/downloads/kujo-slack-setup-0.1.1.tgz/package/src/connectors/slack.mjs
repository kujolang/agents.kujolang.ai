import {createHmac, timingSafeEqual} from 'node:crypto';
import {id, requireValue, TRANSPORT} from '../protocol.mjs';
import {credential, jsonResponse, plainText, retryAfter} from './provider.mjs';

export function slackEnvelope(raw, headers, config, now = Date.now()) {
  const secret = credential(config.signingSecret);
  const timestamp = headers['x-slack-request-timestamp'];
  const signature = headers['x-slack-signature'];
  requireValue(Buffer.isBuffer(raw) && raw.length <= 65536 && typeof timestamp === 'string'
    && /^\d{10}$/.test(timestamp) && Math.abs(now - Number(timestamp)*1000) <= 300_000
    && typeof signature === 'string' && /^v0=[0-9a-f]{64}$/.test(signature), 'invalid-signature');
  const expected = createHmac('sha256', secret).update(`v0:${timestamp}:`).update(raw).digest('hex');
  requireValue(timingSafeEqual(Buffer.from(expected), Buffer.from(signature.slice(3))), 'invalid-signature');
  let payload;
  try { payload = JSON.parse(raw.toString('utf8')); } catch { requireValue(false, 'invalid-json'); }
  if (payload?.type === 'url_verification') {
    requireValue(typeof payload.challenge === 'string' && payload.challenge.length <= 256, 'invalid-challenge');
    return {challenge: payload.challenge};
  }
  return slackEvent(payload, config);
}

export function slackEvent(payload, config) {
  requireValue(payload?.type === 'event_callback' && payload.api_app_id === id(config.appId)
    && payload.team_id === id(config.teamId), 'account-mismatch');
  const event = payload.event;
  if (!event || event.bot_id || event.bot_profile || event.user === config.botUserId || event.subtype
      || !['app_mention','message'].includes(event.type) || payload.is_ext_shared_channel
      || (event.type === 'message' && !event.thread_ts)) return {ignored:true};
  if (event.type === 'app_mention') requireValue(/^U[A-Z0-9]+$/.test(config.botUserId), 'invalid-bot-id');
  const text = typeof event.text === 'string' && event.type === 'app_mention'
    ? event.text.replace(new RegExp('^<@' + config.botUserId.replace(/[^A-Z0-9]/gi, '') + '>\\s*'), '') : event.text;
  // A typed request can stage only; local admission is a separate operation.
  const request = event.type === 'app_mention' && typeof text === 'string' && text.startsWith('request: ');
  return {platform:'slack', account:config.teamId, occurrence:id(payload.event_id),
    subject:id(event.user), room:id(event.channel), root:id(event.thread_ts ?? event.ts),
    type:request ? 'task.request' : 'message', text:request ? text.slice(9) : text};
}

export function slackTransport({token, teamId, botUserId, fetcher = fetch, render = event => ({text:plainText(event), mrkdwn:false})}) {
  credential(token);
  async function call(method, input) {
    return fetcher('https://slack.com/api/' + method, {
      method:'POST', headers:{authorization:`Bearer ${token}`, 'content-type':'application/json'},
      body:JSON.stringify(input), redirect:'error', signal:AbortSignal.timeout(10000),
    });
  }
  return {
    schema:TRANSPORT, platform:'slack', externalAccount:teamId,
    async health() {
      const response = await call('auth.test', {});
      const data = response.ok ? await jsonResponse(response) : {};
      return {ok:data.ok === true && data.team_id === teamId && data.user_id === botUserId};
    },
    async send({room, root, event}) {
      const response = await call('chat.postMessage', {channel:room, thread_ts:root,
        ...render(event,room), unfurl_links:false, unfurl_media:false,
        link_names:false, parse:'none'});
      if (response.status === 429) return retryAfter(response);
      if (response.status >= 500) return {state:'ambiguous'};
      if (!response.ok) return {state:'dead'};
      const result = await jsonResponse(response);
      return result.ok === true ? {state:'sent', ref:id(result.ts)} : {state:'dead'};
    },
  };
}


// Each configured deployment uses its own installed app's bot token.
export function slackAgentTransport({teamId, agents, reviewUsers = {}, fetcher = fetch}) {
  const users = new Map(Object.entries(agents).map(([deployment, bot]) => [id(deployment), slackUser(bot.userId)]));
  const botIds = new Set(users.values());
  requireValue(users.size > 0 && botIds.size === users.size, 'invalid-slack-agent-identities');
  const reviewers = new Map(Object.entries(reviewUsers).map(([room, user]) => [id(room), slackUser(user)]));
  requireValue([...reviewers.values()].every(user => !botIds.has(user)), 'invalid-slack-reviewer');

  const senders = new Map(Object.entries(agents).map(([deployment, bot]) => [deployment, slackTransport({
    token:bot.token, teamId, botUserId:users.get(deployment), fetcher,
    render(event, room) {
      const mentioned = (event.data.mentions ?? []).map(key => users.get(key)).filter(Boolean);
      const reviewer = event.data.type === 'approval.request' && reviewers.get(room);
      if (reviewer) mentioned.push(reviewer);
      const prefix = [...new Set(mentioned)].map(user => `<@${user}>`).join(' ');
      const text = event.data.text.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
        .replace(/[@*_~`]/gu,character => ({'@':'＠','*':'＊','_':'＿','~':'～','`':'｀'})[character]);
      return {text:prefix ? prefix + ' ' + text : text, mrkdwn:true};
    },
  })]));
  return {
    schema:TRANSPORT, platform:'slack', externalAccount:teamId,
    async health() {
      const statuses = await Promise.all([...senders.values()].map(sender => sender.health()));
      return {ok:statuses.every(status => status.ok)};
    },
    async send(delivery) {
      const sender = delivery.event.actor.kind === 'agent' && senders.get(delivery.event.actor.id);
      return sender ? sender.send(delivery) : {state:'dead'};
    },
  };
}

function slackUser(user) {
  requireValue(typeof user === 'string' && /^[UW][A-Z0-9]+$/.test(user), 'invalid-slack-user');
  return user;
}
