import {id, requireValue, TRANSPORT} from '../protocol.mjs';
import {credential, jsonResponse, plainText, retryAfter} from './provider.mjs';

export function matrixEnvelope(event, room, botUserId) {
  if (event?.type !== 'm.room.message' || event.sender === botUserId || event.unsigned?.redacted_because
      || event.content?.msgtype !== 'm.text') return null;
  const relation = event.content['m.relates_to'];
  if (relation?.rel_type === 'm.replace') return null;
  const root = relation?.rel_type === 'm.thread' ? relation.event_id
    : relation?.['m.in_reply_to']?.event_id ?? event.event_id;
  const text = event.content.body;
  const request = typeof text === 'string' && text.startsWith('!kujo request ');
  return {platform:'matrix', account:id(botUserId), occurrence:id(event.event_id), subject:id(event.sender),
    room:id(room), root:id(root), type:request ? 'task.request' : 'message', text:request ? text.slice(14) : text};
}

export function matrixTransport({homeserver, token, botUserId, fetcher = fetch}) {
  credential(token);
  const base = new URL(homeserver);
  requireValue(base.protocol === 'https:' && !base.username && !base.password
    && base.pathname === '/' && !base.search && !base.hash, 'invalid-homeserver');
  async function http(path, method = 'GET', body) {
    return fetcher(new URL('/_matrix/client/v3/' + path, base), {method,
      headers:{authorization:`Bearer ${token}`, 'content-type':'application/json'},
      ...(body === undefined ? {} : {body:JSON.stringify(body)}), redirect:'error', signal:AbortSignal.timeout(15000)});
  }
  return {
    schema:TRANSPORT, platform:'matrix', externalAccount:botUserId,
    async health() {
      const response = await http('account/whoami');
      return {ok:response.ok && (await jsonResponse(response)).user_id === botUserId};
    },
    async sync(since, rooms) {
      requireValue(Array.isArray(rooms) && rooms.length > 0 && rooms.length <= 16, 'invalid-room-filter');
      const filter = JSON.stringify({room:{rooms:rooms.map(id),
        timeline:{types:['m.room.message'],limit:50}, state:{types:['m.room.encryption']}}});
      const query = new URLSearchParams({timeout:'5000',filter,full_state:'true',...(since ? {since} : {})});
      const response = await http('sync?' + query);
      if (response.status === 429) return retryAfter(response);
      requireValue(response.ok, 'matrix-sync-failed');
      const data = await jsonResponse(response);
      requireValue(typeof data.next_batch === 'string' && data.next_batch.length <= 4096, 'invalid-matrix-cursor');
      const events = [];
      for (const room of rooms) {
        const state = data.rooms?.join?.[room];
        requireValue(!state?.state?.events?.some(event => event.type === 'm.room.encryption'), 'matrix-encryption-unsupported');
        requireValue(!since || !state?.timeline?.limited, 'matrix-sync-gap');
        if (since) {
          for (const event of state?.timeline?.events ?? []) {
            const normal = matrixEnvelope(event, room, botUserId);
            if (normal) events.push(normal);
          }
        }
      }
      return {cursor:data.next_batch, events};
    },
    async send({room, root, deliveryId, event}) {
      const state = await http(`rooms/${encodeURIComponent(id(room))}/state/m.room.encryption`);
      // Matrix state GET can return a matching event or M_NOT_FOUND. Other responses abstain.
      if (state.status === 429) return retryAfter(state);
      if (state.status !== 404 || (await jsonResponse(state)).errcode !== 'M_NOT_FOUND') return {state:'dead'};
      const response = await http(`rooms/${encodeURIComponent(room)}/send/m.room.message/${encodeURIComponent(id(deliveryId))}`,
        'PUT', {msgtype:'m.text', body:plainText(event),
          'm.relates_to':{rel_type:'m.thread',event_id:id(root),'m.in_reply_to':{event_id:root},is_falling_back:true}});
      if (response.status === 429) return retryAfter(response);
      if (response.status >= 500) return {state:'ambiguous'};
      if (!response.ok) return {state:'dead'};
      return {state:'sent', ref:id((await jsonResponse(response)).event_id)};
    },
  };
}
