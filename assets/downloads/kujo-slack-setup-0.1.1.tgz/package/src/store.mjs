import {DatabaseSync} from 'node:sqlite';
import {constants, openSync, closeSync, lstatSync, realpathSync} from 'node:fs';
import {dirname, resolve} from 'node:path';
import {requireValue} from './protocol.mjs';

export function sqlite(filename = ':memory:') {
  if (filename !== ':memory:') {
    filename = resolve(filename);
    const parent = dirname(filename);
    const directory = lstatSync(parent);
    requireValue(realpathSync(parent) === parent && directory.isDirectory()
      && directory.uid === process.getuid() && (directory.mode & 0o077) === 0, 'unsafe-store-directory');
    const fd = openSync(filename, constants.O_CREAT | constants.O_RDWR | constants.O_NOFOLLOW | constants.O_NONBLOCK, 0o600);
    closeSync(fd);
    const file = lstatSync(filename);
    requireValue(file.isFile() && file.nlink === 1 && file.uid === process.getuid()
      && (file.mode & 0o077) === 0, 'unsafe-store-file');
  }
  const db = new DatabaseSync(filename);
  db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; PRAGMA busy_timeout=2000;');
  const version = db.prepare('PRAGMA user_version').get().user_version;
  requireValue(version === 0 || version === 1, 'unsupported-store-version');
  db.exec(`
    CREATE TABLE IF NOT EXISTS entity (
      kind TEXT NOT NULL, scope TEXT NOT NULL, id TEXT NOT NULL, value TEXT NOT NULL,
      PRIMARY KEY(kind,scope,id)
    ) STRICT;
    CREATE TABLE IF NOT EXISTS event (
      seq INTEGER PRIMARY KEY AUTOINCREMENT, workspace TEXT NOT NULL, thread TEXT NOT NULL,
      id TEXT UNIQUE NOT NULL, source TEXT NOT NULL, occurrence TEXT NOT NULL,
      hash TEXT NOT NULL, created INTEGER NOT NULL, value TEXT NOT NULL,
      UNIQUE(workspace,source,occurrence)
    ) STRICT;
    CREATE INDEX IF NOT EXISTS event_workspace_seq ON event(workspace,seq);
    CREATE TABLE IF NOT EXISTS delivery (
      id TEXT PRIMARY KEY, workspace TEXT NOT NULL, connection TEXT NOT NULL, eventId TEXT NOT NULL,
      thread TEXT NOT NULL, state TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
      due INTEGER NOT NULL, result TEXT, FOREIGN KEY(eventId) REFERENCES event(id) ON DELETE CASCADE
    ) STRICT;
    CREATE INDEX IF NOT EXISTS delivery_due ON delivery(state,due,connection);
    PRAGMA user_version=1;
  `);
  return {
    run: (sql, ...args) => db.prepare(sql).run(...args),
    get: (sql, ...args) => db.prepare(sql).get(...args),
    all: (sql, ...args) => db.prepare(sql).all(...args),
    transaction(fn) {
      db.exec('BEGIN IMMEDIATE');
      try {
        const result = fn();
        db.exec('COMMIT');
        return result;
      } catch (error) {
        db.exec('ROLLBACK');
        throw error;
      }
    },
    close: () => db.close(),
  };
}
