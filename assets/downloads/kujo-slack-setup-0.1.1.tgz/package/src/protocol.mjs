import {createHash} from 'node:crypto';

export const PROTOCOL = 'kujo.collaboration.event/v1';
export const HOST = 'kujo.collaboration.host/v1';
export const TRANSPORT = 'kujo.collaboration.transport/v1';
export const TYPES = Object.freeze(['message', 'task.request', 'delegation.request', 'review.request',
  'approval.request', 'status', 'execution.observation']);
export const REQUESTS = Object.freeze(['task.request', 'delegation.request', 'review.request']);
export const ID = /^[a-zA-Z0-9._:@$!+=/~-]{1,200}$/;

export class Rejected extends Error {
  constructor(code) {
    super(code);
    this.code = code;
  }
}

export function requireValue(condition, code) {
  if (!condition) throw new Rejected(code);
}

export function id(value) {
  requireValue(typeof value === 'string' && ID.test(value), 'invalid-id');
  return value;
}

export function digest(value) {
  return createHash('sha256').update(JSON.stringify(value)).digest('hex');
}

export function body(value) {
  requireValue(typeof value === 'string' && value.trim() && Buffer.byteLength(value) <= 4096
    && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(value), 'invalid-text');
  return value.replace(/\b(?:xox[a-z]-[\w-]+|sk-[\w-]{12,}|gh[pousr]_[\w]{12,})\b/gi, '[redacted]')
    .replace(/\b(bearer)\s+[\w.+/=~-]{12,}/gi, '$1 [redacted]')
    .replace(/\b(token|password|api[_-]?key)(\s*[:=]\s*)[^\s,;]{6,}/gi, '$1$2[redacted]');
}

export function content(input) {
  requireValue(input && TYPES.includes(input.type), 'unsupported-operation');
  const mentions = input.mentions ?? [];
  requireValue(Array.isArray(mentions) && mentions.length <= 8, 'invalid-mentions');
  const evidence = input.evidence ?? [];
  requireValue(Array.isArray(evidence) && evidence.length <= 8, 'invalid-evidence');
  return {
    type: input.type,
    text: body(input.text),
    mentions: [...new Set(mentions.map(id))],
    ...(input.target ? {target: id(input.target)} : {}),
    ...(input.replyTo ? {replyTo: id(input.replyTo)} : {}),
    ...(input.cause ? {cause: id(input.cause)} : {}),
    evidence: evidence.map(item => {
      requireValue(item && /^[0-9a-f]{64}$/.test(item.sha256), 'invalid-evidence');
      return {kind: id(item.kind), ref: id(item.ref), sha256: item.sha256};
    }),
  };
}
