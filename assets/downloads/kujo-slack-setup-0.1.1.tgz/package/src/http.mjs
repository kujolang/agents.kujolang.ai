import {Rejected} from './protocol.mjs';
import {slackEnvelope} from './connectors/slack.mjs';

// Mount behind a trusted TLS reverse proxy. No operator/control routes are exposed.
export function slackReceiver({core, workspace, connection, config, clock = Date.now}) {
  return async (request, response) => {
    const reply = (status, data) => {
      response.writeHead(status, {'content-type':'application/json'});
      response.end(JSON.stringify(data));
    };
    if (request.method !== 'POST' || request.url !== '/slack/events') return reply(404, {error:'not-found'});
    try {
      const parts = [];
      let size = 0;
      for await (const part of request) {
        size += part.length;
        if (size > 65536) { request.destroy(); return; }
        parts.push(part);
      }
      const input = slackEnvelope(Buffer.concat(parts), request.headers, config, clock());
      if (input.challenge) return reply(200, {challenge:input.challenge});
      if (input.ignored) return reply(200, {ok:true});
      core.inbound(workspace, connection, input);
      return reply(200, {ok:true});
    } catch (error) {
      if (error instanceof Rejected) {
        if (['invalid-signature','account-mismatch'].includes(error.code)) return reply(401, {error:'unauthenticated'});
        if (['journal-full','queue-full'].includes(error.code)) return reply(503, {error:'local-capacity'});
        // Authenticated but out-of-scope deliveries are terminal for this installation.
        return reply(200, {ok:false,error:error.code});
      }
      return reply(503, {error:'unavailable'});
    }
  };
}
