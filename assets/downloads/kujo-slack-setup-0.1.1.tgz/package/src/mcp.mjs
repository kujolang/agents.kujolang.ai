import {requireValue} from './protocol.mjs';

// This handler is workspace-fixed and read-only. The local process must be
// launched by the workspace operator and bound to a trusted stdio client.
export function mcpHandler(core, workspace) {
  let initialized = false;
  const definitions = [
    {name:'collaboration_roster',description:'List scoped deployments and capabilities.',
      inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true}},
    {name:'collaboration_delivery_status',description:'Read scoped outbound delivery states.',
      inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true}},
  ];
  return request => {
    const requestId = request?.id;
    if (request?.jsonrpc !== '2.0' || !Object.hasOwn(request,'id')) return null;
    const reply = data => ({jsonrpc:'2.0',id:requestId,...data});
    try {
      if (request.method === 'initialize') {
        initialized = true;
        return reply({result:{protocolVersion:'2025-11-25',capabilities:{tools:{}},
          serverInfo:{name:'kujo-agent-collaboration-read',version:'0.1.0'}}});
      }
      requireValue(initialized, 'initialize-required');
      if (request.method === 'ping') return reply({result:{}});
      if (request.method === 'tools/list') return reply({result:{tools:definitions}});
      if (request.method !== 'tools/call') return reply({error:{code:-32601,message:'Method not found'}});
      const args = request.params?.arguments ?? {};
      requireValue(args && typeof args === 'object' && !Array.isArray(args)
        && Object.keys(args).length === 0, 'invalid-parameters');
      const tool = request.params?.name;
      requireValue(definitions.some(entry => entry.name === tool), 'unknown-tool');
      const records = tool === 'collaboration_roster' ? core.discover(workspace) : core.deliveries(workspace);
      // Bound responses independently of the database quota.
      return reply({result:{content:[{type:'text',text:JSON.stringify(records.slice(0,100))}]}});
    } catch {
      return reply({error:{code:-32602,message:'Unavailable or invalid request'}});
    }
  };
}

export async function serveReadOnly({input,output,handle}) {
  let pending = Buffer.alloc(0);
  for await (const chunk of input) {
    pending = Buffer.concat([pending,Buffer.from(chunk)]);
    for (;;) {
      const end = pending.indexOf(10);
      if (end < 0) break;
      requireValue(end <= 65536, 'mcp-frame-limit');
      const frame = pending.subarray(0,end);
      pending = pending.subarray(end+1);
      let value;
      try { value = JSON.parse(frame.toString('utf8')); }
      catch { value = null; }
      const response = !value ? {jsonrpc:'2.0',id:null,error:{code:-32700,message:'Parse error'}} : handle(value);
      if (response) await new Promise((resolve,reject) => output.write(JSON.stringify(response)+'\n',
        error => error ? reject(error) : resolve()));
    }
    requireValue(pending.length <= 65536, 'mcp-frame-limit');
  }
  requireValue(pending.length === 0, 'incomplete-mcp-frame');
}
