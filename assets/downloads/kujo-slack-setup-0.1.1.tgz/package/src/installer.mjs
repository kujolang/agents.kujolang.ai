import {spawnSync} from 'node:child_process';
import {realpathSync, statSync} from 'node:fs';
import {isAbsolute, join} from 'node:path';
import {loadCatalog} from './onboarding.mjs';
import {requireValue} from './protocol.mjs';

// The operator selects a trusted canonical Kujo checkout. This wrapper never
// downloads a script, interprets registry text as argv, or authorizes effects.
export function installCatalog({kujoRoot, prefix, binDir, catalogSha, apply = false, env = process.env}) {
  requireValue(isAbsolute(prefix) && isAbsolute(binDir) && /^[a-f0-9]{40}$/.test(catalogSha), 'invalid-install-plan');
  const root = realpathSync(kujoRoot);
  const installer = join(root, 'install.sh');
  requireValue(realpathSync(installer) === installer && statSync(installer).isFile(), 'canonical-installer-missing');
  const args = [installer, '--group', 'operating', '--prefix', prefix, '--bin-dir', binDir,
    '--repo-ref', `kujo-agents=${catalogSha}`, ...(apply ? [] : ['--dry-run'])];
  const runtime = spawnSync('bash', args, {cwd:root, env:{...env,KUJO_INSTALL_ROOT:prefix,KUJO_BIN_DIR:binDir}, stdio:apply ? 'inherit' : 'pipe',
    encoding:'utf8', timeout:600_000, maxBuffer:524288});
  requireValue(runtime.status === 0, 'canonical-install-failed');
  if (!apply) return {mode:'dry-run', output:runtime.stdout};
  const destination = join(prefix, 'sources', 'kujo-agents');
  const commit = spawnSync('git',['rev-parse','HEAD'],{cwd:destination,encoding:'utf8',timeout:10000});
  requireValue(commit.status === 0 && commit.stdout.trim() === catalogSha, 'catalog-pin-mismatch');
  return {mode:'installed', catalog:destination, agents:loadCatalog(destination).length};
}
