import {digest, HOST, requireValue} from '../protocol.mjs';
import {requestSpecialist} from './reference.mjs';

// Bounded advisory workflow. The caller must be a local operator authorized to admit both requests.
export async function runTeamReview({core, workspace, eventId, operator, coordinator, specialist, propose}) {
  const parent = core.event(workspace,eventId);
  requireValue(parent.actor.kind === 'human' && parent.data.type === 'task.request'
    && parent.data.target === coordinator, 'invalid-team-review-request');
  const roster = core.discover(workspace);
  const lead = roster.find(agent => agent.id === coordinator);
  const peer = roster.find(agent => agent.id === specialist);
  requireValue(lead?.hostId && lead.hostId === peer?.hostId && coordinator !== specialist
    && lead.operations.includes('delegation.request')
    && peer.capabilities.includes('delegation.request'), 'invalid-team-review-roster');

  let handoff;
  const results = {};
  const host = {
    id:lead.hostId, schema:HOST, operations:['task.request','delegation.request'],
    async accept({event,deployment}) {
      const stage = event.id === eventId && deployment.id === coordinator ? 'delegate' : 'specialist';
      requireValue(stage === 'delegate' || (event.id === handoff?.id && deployment.id === specialist),
        'unexpected-team-request');
      const result = await propose({stage,deployment,request:event,brief:parent.data.text});
      validateResult(stage,result);
      results[stage] = result;
      return {state:'accepted',ref:result.evidence.ref};
    },
  };

  const publish = (actor,cause,type,text,result,stage,mentions=[]) => core.post(workspace,parent.threadId,
    {kind:'agent',id:actor},{type,text,cause,mentions,evidence:[result.evidence]},digest([eventId,stage])).event;

  await core.admit(workspace,eventId,operator,host);
  const delegation = results.delegate;
  handoff = requestSpecialist(core,workspace,parent,coordinator,specialist,delegation.message,
    digest([eventId,'delegate'])).event;
  publish(coordinator,handoff.id,'message',delegation.message,delegation,'assigned',[specialist]);

  await core.admit(workspace,handoff.id,operator,host);
  const review = results.specialist;
  publish(specialist,handoff.id,'execution.observation',review.message,review,'result',[coordinator]);

  const decision = await propose({stage:'decision',deployment:lead,request:handoff,brief:parent.data.text,
    specialistResult:review.message});
  validateResult('decision',decision);
  publish(coordinator,handoff.id,'message',decision.message,decision,'decision',[specialist]);
  const approval = decision.reviewQuestion
    ? publish(coordinator,handoff.id,'approval.request',decision.reviewQuestion,decision,'human-review')
    : null;
  return {requestId:eventId,delegationId:handoff.id,threadId:parent.threadId,correlationId:parent.correlationId,
    ...(approval ? {reviewEventId:approval.id} : {})};
}

function validateResult(stage,result) {
  const plainLine = text => typeof text === 'string' && text.trim().length > 0
    && Buffer.byteLength(text) <= 1600 && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(text);
  requireValue(plainLine(result?.message) && result.evidence?.kind === 'provider-receipt'
    && typeof result.evidence.ref === 'string' && /^[a-f0-9]{64}$/.test(result.evidence.sha256),
    'invalid-team-proposal');
  if (stage === 'decision') requireValue(result.reviewQuestion === '' || plainLine(result.reviewQuestion),
    'invalid-team-review-question');
}
