import {digest, HOST, REQUESTS, requireValue} from '../protocol.mjs';

// Deterministic no-effect host. Native execution hosts replace this implementation.
export function referenceHost(hostId = 'fixture') {
  return {
    schema:HOST, id:hostId, operations:[...REQUESTS],
    async accept({event, deployment}) {
      requireValue(event.data.target === deployment.id && REQUESTS.includes(event.data.type), 'request-forbidden');
      return {state:'accepted',ref:'receipt-' + digest([hostId,event.id]).slice(0,32)};
    },
  };
}

export function suggestSpecialists(core, workspace, operation, exclude) {
  return core.discover(workspace).filter(agent => agent.id !== exclude && agent.capabilities.includes(operation));
}

export function requestSpecialist(core, workspace, parent, coordinator, specialist, text, occurrence) {
  return core.post(workspace, parent.threadId, {kind:'agent', id:coordinator},
    {type:'delegation.request', cause:parent.id, target:specialist, text}, occurrence);
}
