import {digest, id, requireValue} from '../protocol.mjs';

// The operator supplies a state object obtained from the WebOps controller.
// No external message may choose the evidence path or invoke a WebOps command.
export function webOpsObservation(state) {
  const {id:runId, status, mode, packageSha256} = state ?? {};
  requireValue(['running','blocked','approval_required'].includes(status)
    && ['fixture','live'].includes(mode), 'invalid-webops-state');
  id(runId);
  const source = {runId,status,mode};
  if (packageSha256 && /^[0-9a-f]{64}$/.test(packageSha256)) source.packageSha256 = packageSha256;
  return {type:'execution.observation',text:`WebOps reported ${status} (${mode}).`,
    evidence:[{kind:'webops-state-observation',ref:runId,sha256:digest(source)}]};
}
