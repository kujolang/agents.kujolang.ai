import {createHmac} from 'node:crypto';
import {mkdtempSync, rmSync, realpathSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createServer} from 'node:http';
import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createCollaboration} from '../src/core.mjs';
import {sqlite} from '../src/store.mjs';
import {HOST, TRANSPORT} from '../src/protocol.mjs';
import {slackEnvelope,slackTransport} from '../src/connectors/slack.mjs';
import {matrixEnvelope,matrixTransport} from '../src/connectors/matrix.mjs';
import {slackReceiver} from '../src/http.mjs';
import {referenceHost, requestSpecialist, suggestSpecialists} from '../src/hosts/reference.mjs';

const NOW = 1795183200000;
const config = {signingSecret:'fixture-signing-key',appId:'A123',teamId:'T123',botUserId:'U999'};
const commander = {id:'commander',definitionId:'chain.general-commander',hostId:'fixture',
  capabilities:['task.request'],operations:['delegation.request']};
const video = {id:'producer',definitionId:'videoops.producer',hostId:'fixture',capabilities:['delegation.request']};

function setup(t, store, clock) {
  const core = createCollaboration({store, clock});
  t.after(() => core.close());
  core.workspace('alpha');
  core.workspace('beta');
  core.human('alpha','operator',['task.request','admit']);
  core.human('alpha','viewer');
  core.agent('alpha',commander);
  core.agent('alpha',video);
  core.connection('alpha',{id:'slack1',platform:'slack',externalAccount:'T123'});
  core.map('alpha','slack1','U123','operator');
  core.link('alpha',{connection:'slack1',room:'C123',root:'12.34',threadId:'project',defaultAgent:'commander',publish:true});
  core.connection('alpha',{id:'matrix1',platform:'matrix',externalAccount:'@kujo:example.test'});
  core.map('alpha','matrix1','@user:example.test','operator');
  core.link('alpha',{connection:'matrix1',room:'!test:example.test',root:'$root',threadId:'project',defaultAgent:'commander',publish:true});
  return core;
}

function signed(event = {}, outer = {}, at = NOW) {
  const raw = Buffer.from(JSON.stringify({type:'event_callback',team_id:'T123',api_app_id:'A123',
    event_id:'Ev123',event:{type:'app_mention',user:'U123',channel:'C123',ts:'12.34',
      text:'<@U999> request: Pick a specialist',...event},...outer}));
  const timestamp = String(at / 1000);
  const signature = createHmac('sha256', config.signingSecret).update(`v0:${timestamp}:`).update(raw).digest('hex');
  return {raw, headers:{'x-slack-request-timestamp':timestamp,'x-slack-signature':`v0=${signature}`}};
}

test('signed Slack and Matrix fixture share identities, explicit admission, specialist, receipts and replies', async t => {
  const core = setup(t,undefined,()=>NOW);
  const inbound = signed();
  const slack = slackEnvelope(inbound.raw,inbound.headers,config,NOW);
  const staged = core.inbound('alpha','slack1',slack).event;
  assert.equal(core.request('alpha',staged.id).state,'staged');
  assert.equal(core.inbound('alpha','slack1',slack).duplicate,true);
  const host = referenceHost();
  assert.equal((await core.admit('alpha',staged.id,'operator',host)).state,'accepted');
  await assert.rejects(core.admit('alpha',staged.id,'operator',host), /request-unavailable/);
  assert.deepEqual(suggestSpecialists(core,'alpha','delegation.request','commander').map(v=>v.id),['producer']);
  const handoff = requestSpecialist(core,'alpha',staged,'commander','producer','Prepare bounded video advice.','one').event;
  assert.equal(handoff.correlationId,staged.correlationId);
  assert.throws(()=>requestSpecialist(core,'alpha',staged,'commander','producer','Repeat','two'), /delegation-forbidden/);
  const receipt = await core.admit('alpha',handoff.id,'operator',host);
  const reply = core.post('alpha','project',{kind:'agent',id:'producer'},
    {type:'execution.observation',text:'Fixture advice ready',cause:handoff.id,
      evidence:[{kind:'fixture-receipt',ref:receipt.ref,sha256:'a'.repeat(64)}]},'three').event;
  const sends=[];
  const slackAdapter=slackTransport({token:'fixture-token',teamId:'T123',fetcher:async (url, options)=>{
    assert.equal(url,'https://slack.com/api/chat.postMessage');
    sends.push(JSON.parse(options.body));
    return Response.json({ok:true,ts:'56.78'});
  }});
  assert.equal((await core.deliver('alpha','slack1',slackAdapter)).state,'sent');
  assert.equal(sends[0].thread_ts,'12.34');
  const matrixAdapter=matrixTransport({homeserver:'https://example.test',token:'fixture-token',botUserId:'@kujo:example.test',
    fetcher: async (url,options)=>{
      if (url.pathname.endsWith('m.room.encryption')) return Response.json({errcode:'M_NOT_FOUND'},{status:404});
      assert.equal(options.method,'PUT');
      sends.push(JSON.parse(options.body));
      return Response.json({event_id:'$reply'});
    }});
  assert.equal((await core.deliver('alpha','matrix1',matrixAdapter)).state,'sent');
  assert.equal(sends[1]['m.relates_to'].event_id,'$root');
  assert.equal(sends[0].text,sends[1].body);
  const matrix=matrixEnvelope({type:'m.room.message',sender:'@user:example.test',event_id:'$user',
    content:{msgtype:'m.text',body:'!kujo request Find another specialist','m.relates_to':{rel_type:'m.thread',event_id:'$root'}}},
  '!test:example.test','@kujo:example.test');
  const again=core.inbound('alpha','matrix1',matrix).event;
  assert.equal(again.actor.id,staged.actor.id);
  assert.equal(again.data.target,staged.data.target);
  assert.equal(again.schema,reply.schema);
  assert.deepEqual(core.replay('beta'),[]);
});

test('validates signature, freshness, account, and controls loop sources', t => {
  const core=setup(t);
  const {raw,headers}=signed();
  assert.throws(()=>slackEnvelope(raw,headers,config,NOW+301000), /invalid-signature/);
  assert.throws(()=>slackEnvelope(Buffer.concat([raw,Buffer.from(' ')]),headers,config,NOW), /invalid-signature/);
  const badTeam=signed({}, {team_id:'T999'});
  assert.throws(()=>slackEnvelope(badTeam.raw,badTeam.headers,config,NOW), /account-mismatch/);
  const bot=signed({bot_id:'B123'});
  assert.deepEqual(slackEnvelope(bot.raw,bot.headers,config,NOW),{ignored:true});
  assert.equal(matrixEnvelope({type:'m.room.message',sender:'@kujo:example.test'},'!room:example.test','@kujo:example.test'),null);
  const event=slackEnvelope(raw,headers,config,NOW);
  assert.throws(()=>core.inbound('alpha','slack1',{...event,subject:'U222'}), /unmapped-subject/);
  assert.throws(()=>core.inbound('alpha','slack1',{...event,root:'2.3'}), /conversation-not-linked/);
  core.allowRoom('alpha',{connection:'slack1',room:'C123',defaultAgent:'commander'});
  assert.ok(core.inbound('alpha','slack1',{...event,root:'2.3'}).event.threadId);
  assert.throws(()=>core.inbound('alpha','slack1',event), /occurrence-conflict/);
  assert.throws(()=>slackTransport({}), /missing-credential/);
});

test('loopback Slack HTTP transport accepts durable duplicate and rejects invalid signature', async t => {
  const core=setup(t,undefined,()=>NOW);
  const server=createServer(slackReceiver({core,workspace:'alpha',connection:'slack1',config,clock:()=>NOW}));
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const url=`http://127.0.0.1:${server.address().port}/slack/events`;
  const {raw,headers}=signed();
  for (let i=0;i<2;i++) assert.equal((await fetch(url,{method:'POST',body:raw,headers})).status,200);
  assert.equal(core.replay('alpha').length,1);
  assert.equal((await fetch(url,{method:'POST',body:raw})).status,401);
});

test('denies cross-workspace actors, out-of-order references, unauthorized actions and revoked mappings', async t => {
  const core=setup(t);
  const human={kind:'human',id:'operator'};
  const actor={kind:'human',id:'viewer'};
  const data={type:'task.request',target:'commander',text:'Start'};
  assert.throws(()=>core.post('beta','project',human,data,'one'), /actor-not-enrolled/);
  assert.throws(()=>core.post('alpha','project',actor,data,'one'), /request-forbidden/);
  assert.throws(()=>core.post('alpha','project',human,{...data,target:'producer'},'one'), /missing-capability/);
  assert.throws(()=>core.post('alpha','project',human,{...data,replyTo:'future'},'one'), /unknown-reply/);
  assert.throws(()=>core.post('alpha','project',human,{type:'approval.request',text:'approve'},'two'), /observation-forbidden/);
  const {raw,headers}=signed();
  const event=core.inbound('alpha','slack1',slackEnvelope(raw,headers,config,NOW)).event;
  await assert.rejects(core.admit('alpha',event.id,'viewer',referenceHost()), /admit-forbidden/);
  await assert.rejects(core.admit('alpha',event.id,'operator',{schema:HOST,id:'different',operations:['task.request']}), /incompatible-host/);
  core.unmap('alpha','slack1','U123');
  await assert.rejects(core.admit('alpha',event.id,'operator',referenceHost()), /mapping-revoked/);
  core.revoke('alpha','agent','commander');
  assert.throws(()=>core.agent('alpha',commander), /binding-revoked/);
});

test('durable restart, provider rate limit, redaction, ambiguity and bounded retention', async t => {
  const root=mkdtempSync(join(realpathSync(tmpdir()),'kujo-collaboration-'));
  t.after(()=>rmSync(root,{force:true,recursive:true}));
  const file=join(root,'journal.sqlite');
  let now=NOW;
  let release;
  const before=createCollaboration({store:sqlite(file),clock:()=>now,retentionMs:86400_000});
  before.workspace('alpha');
  before.agent('alpha',video);
  before.connection('alpha',{id:'slack1',platform:'slack',externalAccount:'T123'});
  before.link('alpha',{connection:'slack1',room:'C123',root:'12.34',threadId:'project',publish:true});
  const posted=before.post('alpha','project',{kind:'agent',id:'producer'},
    {type:'message',text:'token: secret-12345678'},'one').event;
  assert.match(posted.data.text,/redacted/);
  before.close();
  const core=createCollaboration({store:sqlite(file),clock:()=>now,retentionMs:86400_000});
  t.after(()=>core.close());
  assert.equal(core.replay('alpha')[0].id,posted.id);
  const limited={schema:TRANSPORT,platform:'slack',externalAccount:'T123',send:async()=>({state:'retry',retryMs:5000})};
  assert.equal((await core.deliver('alpha','slack1',limited)).state,'pending');
  assert.equal(await core.deliver('alpha','slack1',limited),null);
  now+=5000;
  const offline={...limited,send:()=>new Promise(resolve=>{release=resolve;})};
  const sending=core.deliver('alpha','slack1',offline);
  now+=121000;
  assert.equal(core.recoverDeliveries('alpha'),1);
  release({state:'sent',ref:'remote'});
  await sending;
  assert.equal(core.deliveries('alpha')[0].state,'ambiguous');
  assert.equal(await core.deliver('alpha','slack1',limited),null);
  now+=86400_001;
  assert.equal(core.prune('alpha'),1);
  assert.deepEqual(core.replay('alpha'),[]);
});

test('Matrix sync drops initial history and refuses encrypted rooms and timeline gaps',async () => {
  let timeline={events:[{sender:'@user:example.test',type:'m.room.message',event_id:'$one',
    content:{msgtype:'m.text',body:'hello'}}]};
  let state={events:[]};
  const adapter=matrixTransport({homeserver:'https://example.test',token:'fixture-token',botUserId:'@kujo:example.test',
    fetcher:async url => {
      assert.equal(url.pathname,'/_matrix/client/v3/sync');
      return Response.json({next_batch:'cursor',rooms:{join:{'!room:example.test':{timeline,state}}}});
    }});
  assert.deepEqual((await adapter.sync(undefined,['!room:example.test'])).events,[]);
  assert.equal((await adapter.sync('old',['!room:example.test'])).events[0].occurrence,'$one');
  timeline={...timeline,limited:true};
  await assert.rejects(adapter.sync('old',['!room:example.test']), /matrix-sync-gap/);
  state={events:[{type:'m.room.encryption'}]};
  await assert.rejects(adapter.sync(undefined,['!room:example.test']), /matrix-encryption-unsupported/);
});
