import {Readable,Writable} from 'node:stream';
import assert from 'node:assert/strict';
import {test} from 'node:test';
import {createCollaboration} from '../src/core.mjs';
import {teamsEnvelope, teamsTransport} from '../src/connectors/teams.mjs';
import {boardObserver,paperclipObserver} from '../src/connectors/external-observation.mjs';
import {mcpHandler,serveReadOnly} from '../src/mcp.mjs';
import {webOpsObservation} from '../src/hosts/webops.mjs';

test('Teams SDK adapter handles tenant-scoped activities and replies using prebound routes', async () => {
  const activity={channelId:'msteams',type:'message',id:'123',replyToId:'root',text:'hello',
    conversation:{id:'19:group@thread.tacv2;messageid=123',tenantId:'tenant'},
    recipient:{id:'28:bot'},from:{id:'29:user',aadObjectId:'actor'}};
  const event=teamsEnvelope(activity,'tenant','28:bot');
  assert.equal(event.subject,'actor');
  assert.equal(event.root,'root');
  assert.throws(()=>teamsEnvelope(activity,'other','28:bot'), /account-mismatch/);
  const adapter=teamsTransport({tenantId:'tenant',routes:new Map([[event.room, activity.conversation.id]]),
    app:{async reply(conversation,root,body) {
      assert.equal(conversation,activity.conversation.id);
      assert.equal(root,'root');
      assert.equal(body.textFormat,'plain');
      return {id:'result'};
    }}});
  const reply={actor:{id:'agent'},data:{text:'response'}};
  assert.deepEqual(await adapter.send({...event,event:reply}),{state:'sent',ref:'result'});
  assert.deepEqual(await adapter.send({...event,room:'unknown',event:reply}),{state:'dead'});
});

test('read-only provider observations preserve native authority and refuse other workspaces', async () => {
  let company='registered';
  const observe=paperclipObserver({origin:'https://paperclip.example',token:'fixture-token',companyId:company,issueIds:['issue'],
    fetcher:async (url,options)=>{
      assert.equal(url.pathname,'/api/issues/issue');
      assert.equal(options.method,undefined);
      return Response.json({id:'issue',companyId:company,status:'blocked',description:'not projected'});
    }});
  assert.equal((await observe('issue')).evidence[0].ref,'issue');
  await assert.rejects(observe('other'), /issue-not-linked/);
  company='other';
  await assert.rejects(observe('issue'), /account-mismatch/);
  const board=boardObserver({threadIds:['root'],board:{thread:async (id, query)=>{
    assert.equal(query.limit,20);
    return {message:{id},replies:[]};
  }}});
  assert.equal((await board('root')).evidence[0].ref,'root');
  await assert.rejects(board('other'), /thread-not-linked/);
  const web=webOpsObservation({id:'webops-fixture',status:'approval_required',mode:'fixture',details:'hidden'});
  assert.match(web.text,/approval_required/);
  assert.doesNotMatch(JSON.stringify(web),/hidden/);
  assert.throws(()=>webOpsObservation({id:'webops-fixture',status:'approved',mode:'fixture'}), /invalid-webops-state/);
});

test('MCP stdio receives split frames and exposes no request or approval tools', async t => {
  const core=createCollaboration();
  t.after(()=>core.close());
  core.workspace('one');
  core.agent('one',{id:'agent',definitionId:'fixture.agent',hostId:'fixture'});
  const messages=[
    {jsonrpc:'2.0',id:1,method:'initialize'},
    {jsonrpc:'2.0',id:2,method:'tools/list'},
    {jsonrpc:'2.0',id:3,method:'tools/call',params:{name:'collaboration_roster'}},
    {jsonrpc:'2.0',id:4,method:'tools/call',params:{name:'collaboration_roster',arguments:{workspace:'two'}}},
  ].map(x=>JSON.stringify(x)+'\n').join('');
  let result='';
  await serveReadOnly({input:Readable.from([messages.slice(0,20),messages.slice(20)]),
    output:new Writable({write(data,_encoding,done){result+=data;done();}}),handle:mcpHandler(core,'one')});
  const replies=result.trim().split('\n').map(JSON.parse);
  assert.ok(replies[1].result.tools.every(tool=>tool.annotations.readOnlyHint));
  assert.equal(JSON.parse(replies[2].result.content[0].text)[0].id,'agent');
  assert.equal(replies[3].error.code,-32602);
});
