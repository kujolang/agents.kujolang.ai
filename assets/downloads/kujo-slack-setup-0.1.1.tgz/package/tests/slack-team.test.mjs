import assert from 'node:assert/strict';
import {test} from 'node:test';
import {slackAgentTransport} from '../src/connectors/slack.mjs';
import {createCollaboration} from '../src/core.mjs';
import {runTeamReview} from '../src/hosts/team-review.mjs';

test('native Slack identities drive visible handoff, response and scoped human review', async t => {
  const core = createCollaboration({clock:()=>1795190000000});
  t.after(() => core.close());
  const ws = 'workspace';
  core.workspace(ws);
  core.human(ws,'operator',['task.request','admit']);
  core.agent(ws,{id:'commander',definitionId:'chain.general-commander',hostId:'team',
    capabilities:['task.request'],operations:['delegation.request']});
  core.agent(ws,{id:'producer',definitionId:'videoops.producer',hostId:'team',capabilities:['delegation.request']});
  core.connection(ws,{id:'slack',platform:'slack',externalAccount:'TTEST'});
  core.map(ws,'slack','UOPERATOR','operator');
  core.allowRoom(ws,{connection:'slack',room:'CTEST',defaultAgent:'commander',publish:true});
  const {event} = core.inbound(ws,'slack',{platform:'slack',account:'TTEST',occurrence:'ETEST',
    subject:'UOPERATOR',room:'CTEST',root:'1.23',type:'task.request',text:'Make a shot list.'});
  const steps = [];
  const propose = async ({stage,deployment, specialistResult}) => {
    steps.push([stage,deployment.id]);
    if (stage === 'decision') assert.equal(specialistResult,'Three shots.');
    return {message:{delegate:'Please script it. <@UOTHER> <!channel>',specialist:'Three shots.',decision:'Let’s use the three-shot plan.'}[stage],
      evidence:{kind:'provider-receipt',ref:'ref-'+stage,sha256:'a'.repeat(64)},reviewQuestion:'Which CTA should we use?'};
  };
  const result = await runTeamReview({core,workspace:ws,eventId:event.id,operator:'operator',
    coordinator:'commander',specialist:'producer',propose});
  assert.deepEqual(steps,[['delegate','commander'],['specialist','producer'],['decision','commander']]);
  assert.equal(result.correlationId,event.correlationId);
  assert.equal(core.request(ws,result.delegationId).state,'accepted');
  assert.equal(core.event(ws,result.reviewEventId).data.type,'approval.request');
  await assert.rejects(runTeamReview({core,workspace:ws,eventId:event.id,operator:'operator',
    coordinator:'commander',specialist:'producer',propose}),/request-unavailable/);
  const emitted = [];
  const adapter = slackAgentTransport({teamId:'TTEST',agents:{
    commander:{userId:'UCOMMAND',token:'commander-fixture-token'},
    producer:{userId:'UPRODUCER',token:'producer-fixture-token'},
  },reviewUsers:{CTEST:'UOPERATOR'},fetcher:async(url,req)=>{
    const sender = req.headers.authorization.includes('commander')?'UCOMMAND':'UPRODUCER';
    if (url.endsWith('/auth.test')) return Response.json({ok:true,team_id:'TTEST',user_id:sender});
    emitted.push({sender,...JSON.parse(req.body)});
    return Response.json({ok:true,ts:'2.'+emitted.length});
  }});
  assert.deepEqual(await adapter.health(),{ok:true});
  for (let i=0;i<4;i++) assert.equal((await core.deliver(ws,'slack',adapter)).state,'sent');
  assert.equal(await core.deliver(ws,'slack',adapter),null);
  assert.deepEqual(new Set(emitted.map(message=>message.thread_ts)),new Set(['1.23']));
  assert.deepEqual(emitted.map(message=>message.sender),['UCOMMAND','UPRODUCER','UCOMMAND','UCOMMAND']);
  assert(emitted[0].text.startsWith('<@UPRODUCER> Please'));
  assert(emitted[3].text.startsWith('<@UOPERATOR>'));
  assert(emitted.some(message=>message.sender==='UPRODUCER'&&message.text==='<@UCOMMAND> Three shots.'));
  assert(emitted.some(message=>message.sender==='UCOMMAND'&&message.text==='<@UOPERATOR> Which CTA should we use?'));
  assert(emitted.every(message=>!message.text.includes('<@UOTHER>')&&!message.text.includes('<!channel>')));
  const proposal = core.replay(ws,{thread:event.threadId}).find(item => item.actor.id==='producer');
  const expectedReply = 'Final CTA: Add an agent to Slack';
  const submitChoice = (occurrence, subject = 'UOPERATOR', root = '1.23') => core.inbound(ws,'slack',{
    platform:'slack',account:'TTEST',occurrence,subject,room:'CTEST',root,type:'task.request',text:expectedReply,
  }).event;
  core.human(ws,'other',['task.request']);
  core.map(ws,'slack','UOTHER','other');
  const answer = submitChoice('EANSWER');
  const differentHuman = submitChoice('EOTHER','UOTHER');
  const differentThread = submitChoice('EELSEWHERE','UOPERATOR','2.34');
  const closure = {reviewId:result.reviewEventId,proposalId:proposal.id,responseId:answer.id,operator:'operator',expectedReply};
  assert.throws(()=>core.completeAdvisoryReview(ws,{...closure,responseId:differentHuman.id}),/invalid-advisory-review/);
  assert.throws(()=>core.completeAdvisoryReview(ws,{...closure,responseId:differentThread.id}),/invalid-advisory-review/);
  assert.throws(()=>core.completeAdvisoryReview(ws,{...closure,expectedReply:'Final CTA: Something else'}),/review-reply-mismatch/);
  assert.equal(core.request(ws,answer.id).state,'staged');
  const completed = core.completeAdvisoryReview(ws,closure);
  assert.equal(completed.correlationId,event.correlationId);
  assert.equal(completed.data.replyTo,answer.id);
  assert.deepEqual(completed.data.evidence,proposal.data.evidence);
  assert.equal(core.request(ws,answer.id).ref,completed.id);
  assert.throws(()=>core.completeAdvisoryReview(ws,closure),/request-unavailable/);
  const duplicate = submitChoice('ESECOND');
  assert.throws(()=>core.completeAdvisoryReview(ws,{...closure,responseId:duplicate.id}),/review-already-closed/);
  assert.equal(core.request(ws,duplicate.id).state,'staged');
  assert.equal((await core.deliver(ws,'slack',adapter)).state,'sent');
  assert.match(emitted[4].text,/Planning review complete. Final CTA: Add an agent to Slack/);
  assert.equal(emitted[4].sender,'UCOMMAND');
  assert.equal(await core.deliver(ws,'slack',adapter),null);
  assert.deepEqual(await adapter.send({event:{actor:{kind:'agent',id:'unknown'}}}),{state:'dead'});
});
