import {readFileSync, mkdtempSync, mkdirSync, realpathSync, rmSync, writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import {test} from 'node:test';
import {loadCatalog, plan, enrollPlan} from '../src/onboarding.mjs';
import {createCollaboration} from '../src/core.mjs';
import {referenceHost} from '../src/hosts/reference.mjs';
import {softwareFactoryHost} from '../src/hosts/software-factory.mjs';

const catalogPath = process.env.KUJO_CATALOG;

test('versioned plan filters incompatibility and stable selections without a factory', t => {
  const catalog = [
    {id:'chain.general-commander',team:'chain-of-command',required:[]},
    {id:'chain.reviewer',team:'chain-of-command',required:['review']},
    {id:'videoops.producer',team:'videoops',required:['media']},
  ];
  const host = {...referenceHost(),profiles:catalog.map(x=>x.id),features:['review']};
  const result = plan({platform:'local',catalog,host,teams:['chain-of-command'],agents:['chain.general-commander']});
  assert.equal(result.choices.length,2);
  const core=createCollaboration();
  t.after(()=>core.close());
  core.workspace('one');
  core.workspace('two');
  const first=enrollPlan(core,'one',result,host);
  assert.deepEqual(first,enrollPlan(core,'one',result,host));
  assert.notEqual(first[0].id,enrollPlan(core,'two',result,host)[0].id);
  assert.notEqual(first[0].id,enrollPlan(core,'one',result,host,'additional')[0].id);
  const conflict=plan({platform:'slack',catalog,host,all:true});
  assert.throws(()=>enrollPlan(core,'one',conflict,host), /plan-not-installable/);
  assert.equal(plan({platform:'teams',catalog,host,all:true}).choices.some(x=>x.available),false);
});

test('canonical catalog supplies complete Chain of Command membership', {skip:!catalogPath}, t => {
  const catalog=loadCatalog(catalogPath);
  const core=createCollaboration();
  t.after(()=>core.close());
  core.workspace('local');
  const fixture=referenceHost();
  const host={...fixture,profiles:catalog.map(x=>x.id),features:[...new Set(catalog.flatMap(x=>x.required))]};
  const result=plan({platform:'local',catalog,host,teams:['chain-of-command']});
  assert.equal(result.choices.length,28);
  const registered=enrollPlan(core,'local',result,host);
  assert.equal(registered.length,28);
  assert.equal(core.discover('local').length,28);
  for (const deployment of registered) core.revoke('local','agent',deployment.id);
  assert.deepEqual(core.discover('local'),[]);
});

test('host failure persists uncertainty and cannot repeat an effect', async t => {
  const core=createCollaboration();
  t.after(()=>core.close());
  const host=referenceHost();
  core.workspace('local');
  core.human('local','operator',['admit','task.request']);
  core.agent('local',{id:'a',definitionId:'chain.general-commander',hostId:host.id,capabilities:host.operations});
  const event=core.post('local','project',{kind:'human',id:'operator'},{type:'task.request',target:'a',text:'Fixture'},'one').event;
  let effects=0;
  const interrupted={...host,accept:async()=>{effects++;throw Error('interrupted');}};
  await assert.rejects(core.admit('local',event.id,'operator',interrupted), /interrupted/);
  assert.equal(core.request('local',event.id).state,'uncertain');
  await assert.rejects(core.admit('local',event.id,'operator',interrupted), /request-unavailable/);
  assert.equal(effects,1);
});

test('Software Factory sealed host prepares through its real control code with no provider calls', {
  skip:!process.env.KUJO_SOFTWARE_FACTORY,
}, async t => {
  const root=mkdtempSync(join(realpathSync(tmpdir()),'collaboration-factory-'));
  t.after(()=>rmSync(root,{force:true,recursive:true}));
  const missionRoot=join(root,'missions');
  const stateRoot=join(root,'state');
  mkdirSync(missionRoot,{mode:0o700});
  mkdirSync(stateRoot,{mode:0o700});
  const capabilityFile=join(root,'grant.json');
  writeFileSync(capabilityFile,JSON.stringify({schema:'kujo.factory.control-grant/v1',uid:process.getuid(),
    missionRoot,stateRoot,actions:['prepare'],expiresAt:new Date(Date.now()+60_000).toISOString(),
    maxMissions:2,maxDurationMs:2000,softwarePack:'converter'}),{mode:0o600});
  const module=pathToFileURL(join(process.env.KUJO_SOFTWARE_FACTORY,'factory/control-mcp.mjs'));
  const {createControlSession}=await import(module.href);
  const session=createControlSession({capabilityFile,allowActions:['prepare']});
  t.after(()=>session.close());
  const host=softwareFactoryHost({control:session,missionRoot});
  const core=createCollaboration();
  t.after(()=>core.close());
  core.workspace('local');
  core.human('local','operator',['admit','task.request']);
  core.agent('local',{id:'commander',definitionId:'chain.general-commander',hostId:host.id,capabilities:host.operations});
  const event=core.post('local','project',{kind:'human',id:'operator'},
    {type:'task.request',target:'commander',text:'Build the sealed converter'},'one').event;
  const result=await core.admit('local',event.id,'operator',host);
  assert.equal(result.state,'accepted');
  assert.equal((await host.status(result.ref)).status,'prepared');
  const receipt=JSON.parse(readFileSync(join(stateRoot,result.ref,'prepared.json')));
  assert.equal(receipt.workflow,'sealed-converter');
  await assert.rejects(host.submitPrepared(result.ref,receipt.missionSha256), /not authorized/);
});

test('operator can dry-run the real canonical installer without changing install roots', {
  skip:!process.env.KUJO_ROOT,
}, async t => {
  const {installCatalog}=await import('../src/installer.mjs');
  const {existsSync}=await import('node:fs');
  const root=mkdtempSync(join(realpathSync(tmpdir()),'collaboration-install-'));
  t.after(()=>rmSync(root,{force:true,recursive:true}));
  const prefix=join(root,'install');
  const binDir=join(root,'bin');
  const result=installCatalog({kujoRoot:process.env.KUJO_ROOT,prefix,binDir,
    catalogSha:'a7e9d0236d6e64b5db30273b32f4ad8c124f5173'});
  assert.equal(result.mode,'dry-run');
  assert.match(result.output,/would write/);
  assert.equal(existsSync(prefix),false);
  assert.equal(existsSync(binDir),false);
});

test('canonical Kujo scaffold builds a standalone stored fixture project', {
  skip:!process.env.KUJO_BIN,
}, async t => {
  const {spawnSync}=await import('node:child_process');
  const root=mkdtempSync(join(realpathSync(tmpdir()),'collaboration-standalone-'));
  t.after(()=>rmSync(root,{force:true,recursive:true}));
  const result=spawnSync(process.env.KUJO_BIN,['agent','new','independent','--dir',root,
    '--profile','basic','--provider','fixture','--no-git','--json'],{encoding:'utf8',timeout:10000});
  assert.equal(result.status,0,result.stderr);
  const outcome=JSON.parse(result.stdout);
  assert.equal(outcome.provider,'fixture');
  assert.equal(outcome.credential_ready,true);
  assert.equal(outcome.path,join(root,'independent'));
  const manifest=JSON.parse(readFileSync(join(outcome.path,'agent.project.json'),'utf8'));
  assert.ok(manifest.agent);
});

test('Factory projection requires a native sealed release record and exposes no raw artifact', async t => {
  const root=mkdtempSync(join(realpathSync(tmpdir()),'collaboration-release-'));
  t.after(()=>rmSync(root,{force:true,recursive:true}));
  let approved=false;
  const host=softwareFactoryHost({missionRoot:root,control:{async call(name,{artifact}) {
    assert.equal(name,'factory_control_read_artifact');
    assert.equal(artifact,'artifacts/release.json');
    return {text:JSON.stringify({status:approved?'approved-local-candidate':'verified-pending-accountability',
      deploymentAuthorized:false,gateVersion:'kujo.factory.release-gates/v3',
      hash:'a'.repeat(64),reviewHash:'a'.repeat(64),details:'hidden'})};
  }}});
  await assert.rejects(host.releaseObservation('receipt','run'), /factory-release-not-observed/);
  approved=true;
  const observed=await host.releaseObservation('receipt','run');
  assert.equal(observed.evidence[0].ref,'run');
  assert.doesNotMatch(JSON.stringify(observed),/hidden/);
});

test('platform-first CLI runs a real local first interaction without Software Factory', {
  skip:!catalogPath,
}, async t => {
  const {spawn}=await import('node:child_process');
  const root=mkdtempSync(join(realpathSync(tmpdir()),'collaboration-onboarding-'));
  t.after(()=>rmSync(root,{force:true,recursive:true}));
  const prompts=[
    ['Where do you want to use your agents?', 'local'],
    ['Workspace ID:', 'independent'],
    ['Agent IDs or team:', 'chain.general-commander'],
    ['Register selected no-effect fixture deployments?', 'yes'],
    ['Local operator ID:', 'operator'],
  ];
  const result=await new Promise((resolve,reject)=>{
    const child=spawn(process.execPath,['bin/collaboration.mjs','setup',join(root,'db'),catalogPath],
      {env:{PATH:process.env.PATH}});
    const timer=setTimeout(()=>child.kill(),5000);
    let output='';
    let error='';
    child.stdout.setEncoding('utf8').on('data', chunk=>{
      output+=chunk;
      if (prompts.length && output.includes(prompts[0][0])) child.stdin.write(prompts.shift()[1]+'\n');
    });
    child.stderr.setEncoding('utf8').on('data', chunk=>{error+=chunk;});
    child.on('error',reject);
    child.on('close',status=>{clearTimeout(timer);resolve({status,output,error});});
  });
  assert.equal(result.status,0,result.error);
  assert.equal(prompts.length,0);
  assert.match(result.output,/"firstInteraction":/);
  assert.match(result.output,/"type": "execution.observation"/);
});
