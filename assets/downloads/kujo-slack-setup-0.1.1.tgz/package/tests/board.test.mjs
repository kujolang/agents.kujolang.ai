import assert from 'node:assert/strict';
import {test} from 'node:test';
import {boardTransport} from '../src/connectors/board.mjs';

test('Board stages only explicitly linked roots and delivers under configured agent profiles', async () => {
  const message = {id:'root-1', channel:'kujo-test', re:null, origin:null,
    text:'request: Review the demo.', by:{principal:'user-1',profile:null}};
  const sent = [];
  const board = {
    async thread() { return {message}; },
    async reply() { assert.fail('Unprofiled write'); },
    as({name}) {
      return {async reply(root, options) { sent.push({name,root,options}); return {id:'reply-1'}; }};
    },
  };
  const transport = boardTransport({board,account:'test',
    threads:{'root-1':'kujo-test'},requestPrincipals:['user-1'],agents:{reviewer:'kujo-reviewer'}});
  assert.deepEqual(await transport.request('root-1'),{
    platform:'board',account:'test',occurrence:'root-1',subject:'user-1',room:'kujo-test',
    root:'root-1',type:'task.request',text:'Review the demo.',
  });
  await assert.rejects(transport.request('not-linked'),/thread-not-linked/);
  message.by.profile = 'agent';
  await assert.rejects(transport.request('root-1'),/unmapped-board-author/);
  message.by.profile = null;
  message.origin = {source:'mirror'};
  await assert.rejects(transport.request('root-1'),/unmapped-board-author/);
  message.channel = 'wrong';
  await assert.rejects(transport.request('root-1'),/invalid-board-root/);
  const event = {actor:{kind:'agent',id:'reviewer',definitionId:'chain.code-reviewer'},
    data:{text:'Review complete. @reviewer'}};
  assert.deepEqual(await transport.send({root:'root-1',room:'wrong',event}),{state:'dead'});
  assert.deepEqual(await transport.send({root:'root-1',room:'kujo-test',event,deliveryId:'delivery-1'}),
    {state:'sent',ref:'reply-1'});
  assert.equal(sent.length,1);
  assert.deepEqual(sent[0].options,{text:'[chain.code-reviewer] Review complete. ＠reviewer',noSync:true,id:'delivery-1'});
  assert.equal(sent[0].name,'kujo-reviewer');
});
