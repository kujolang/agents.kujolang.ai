import assert from 'node:assert/strict';
import {test} from 'node:test';
import {openSlackSocket} from '../src/connectors/slack-socket.mjs';

test('Socket Mode authorizes the Slack app and workspace and acknowledges durable intake', async () => {
  const state = [], messages = [], acks = [];
  let fake;
  class Socket extends EventTarget {
    constructor(url) { super(); assert.equal(new URL(url).protocol,'wss:'); fake=this; }
    send(value) { acks.push(JSON.parse(value)); }
    close() { this.dispatchEvent(new Event('close')); }
    receive(value) { this.dispatchEvent(new MessageEvent('message',{data:JSON.stringify(value)})); }
  }
  const close=await openSlackSocket({appToken:'xapp-fixture-token',config:{appId:'A123',teamId:'T123',botUserId:'U99'},
    onEvent:event=>messages.push(event),onStatus:value=>state.push(value),Socket,
    fetcher:async(url,request)=>{
      assert.equal(url,'https://slack.com/api/apps.connections.open');
      assert.equal(request.redirect,'error');
      return Response.json({ok:true,url:'wss://wss-primary.slack.com/link/?ticket=test'});
    },
  });
  fake.receive({type:'hello',connection_info:{app_id:'A123'}});
  const payload={type:'event_callback',team_id:'T123',api_app_id:'A123',event_id:'Ev1',
    event:{type:'app_mention',user:'U123',channel:'C123',ts:'12.34',text:'<@U99> request: verify'}};
  fake.receive({type:'events_api',envelope_id:'env1',payload});
  assert.equal(messages[0].text,'verify');
  assert.equal(messages[0].occurrence,'Ev1');
  assert.deepEqual(acks,[{envelope_id:'env1'}]);
  fake.receive({type:'events_api',envelope_id:'env2',payload:{...payload,team_id:'T999'}});
  assert.equal(messages.length,1);
  assert.equal(acks.length,1);
  assert.deepEqual(state,['connected','event-rejected']);
  close();

  await assert.rejects(openSlackSocket({appToken:'xapp-fixture-token',fetcher:async()=>
    Response.json({ok:true,url:'wss://wss-primary.slack.com.example.org/link/?ticket=test'})}),/socket-url-rejected/);
});
