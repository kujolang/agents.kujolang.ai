# Kujo Agent Collaboration

Local-first collaboration between independently installed agent hosts and external communication tools. Slack passed a scoped live pilot and Matrix passed offline contract fixtures. This checkout is an unreleased reference. See the [Slack operator setup guide](docs/SLACK-OPERATOR-SETUP.md).

## Start locally

Use Node.js 24 or later on a POSIX host. This repository uses Node SQLite and has no npm dependencies. Use an existing Kujo Agents checkout, or install the catalog with the canonical Kujo ecosystem installer's `--group operating` option after reviewing its dependency plan.

```sh
node bin/collaboration.mjs setup "$HOME/.local/share/kujo-collaboration" /absolute/path/to/kujo-agents
```

Choose a platform first, then supply canonical agent IDs, `team:chain-of-command`, other eligible teams, or `all`. The deterministic host uses no models. It validates required capabilities, enrolls deployments atomically, and returns an initial local request and reply. Repeating the same selection retains deployment identities. The SDK supports more deployment namespaces. Use Kennel for a host's declared packages and its original installer for external tools. See the [installer audit](docs/INSTALLER-AUDIT.md).

Use `roster`, `post`, `request`, `accept-fixture` and `replay` for local interactions. `suggest DB WORKSPACE delegation.request` lists capable deployments. `delegate DB WORKSPACE EVENT COMMANDER SPECIALIST TEXT` stages one specialist handoff for separate operator review. The example is a deterministic coordinator reference.

## Connect a transport

Use an independently authorized test installation. The CLI verifies existing credentials and maps external users to enrolled humans. Use the platform's admin tools to install the app. The setup wizard's external options enroll fixture agents and point to the remaining manual configuration.

1. Create a separate Slack test app with `app_mentions:read` and `chat:write`. Grant history scopes only if threaded message subscriptions are needed. Invite that app to a dedicated channel and set the Events API callback to a trusted TLS reverse proxy forwarding `/slack/events` to the loopback adapter. Set `SLACK_BOT_TOKEN`, `SLACK_APP_ID`, `SLACK_TEAM_ID`, `SLACK_BOT_USER_ID` and `SLACK_SIGNING_SECRET` only in the connector environment.
2. Use a dedicated Matrix account and allowlisted unencrypted rooms. Set `MATRIX_HOMESERVER` to the HTTPS homeserver origin, `MATRIX_ACCESS_TOKEN` and `MATRIX_BOT_USER_ID`. First sync establishes a cursor without importing backlog. A limited timeline halts the connector for reconciliation.
3. Run `health slack` or `health matrix`. Record a connection with `connection DB WORKSPACE PLATFORM CONNECTION EXTERNAL_ACCOUNT`. For Slack the account is the team ID. For Matrix use the dedicated bot user ID. Map humans with `map`, then allow a room with `room`. Use `link` with exact external root IDs to connect two provider threads to the same canonical thread.
4. Start `slack DB WORKSPACE CONNECTION` or `matrix DB WORKSPACE CONNECTION ROOM`. Send a mention or reply from an enrolled account. A Slack mention followed by `request: `, or Matrix `!kujo request `, can stage a request for the default deployment if the sender has permission. Review the event locally before calling the host.

The shared-bot path adds a canonical role prefix. Separate Slack bot profiles use their own names and portraits. Evidence references stay in local replay. Matrix E2EE, proactive root creation, Slack Connect, edits/deletes and attachment mirroring are outside this reference.

## Slack agent identities

A Slack workspace can install one bot app per Kujo deployment. Each app owns its
native Slack profile and avatar. The connector verifies every configured bot
token against its declared user and workspace. It posts as the deployment that
authored the collaboration event and renders native mentions only from
operator-configured mappings. A bot-generated Slack mention is a visible
notification; the typed Kujo handoff authorizes nothing until admitted.

Set `SLACK_AGENT_BOTS` in the local connector process to a JSON object keyed by
deployment ID, with each value containing `userId` and `token`. Set
`SLACK_REVIEW_USERS` to a JSON map from allowed Slack channel IDs to explicit
human reviewer IDs. The inbound signing secret, app ID and bot user ID belong
to the ingress app. The ingress bot needs `app_mentions:read` and `chat:write`.
Outgoing specialists need `chat:write`. Invite both bots to the bound test
channel. No impersonation scope is needed.

The optional operator-run [VideoOps planning example](examples/video-review.mjs)
uses General Commander and VideoOps Producer to produce a timecoded shot list,
agree on the planning direction and ask a human for a decision. It reads
canonical role instructions and uses Software Factory's existing bounded
provider adapters. It supports a text planning deliverable. The full VideoOps
production runtime and rendering require their own host and capabilities.

With owner-only `KUJO_CATALOG` and `KUJO_SOFTWARE_FACTORY` checkout settings,
run `node examples/video-review.mjs enroll DB WORKSPACE COMMANDER PRODUCER` to
register the advisory deployments. Bind the Slack room to the Commander, and
review the staged request before running
`node examples/video-review.mjs run DB WORKSPACE COMMANDER PRODUCER EVENT OPERATOR`.
The local operator admits both typed requests. Inference and replies use three
budgeted model calls. The model can request human review, while approval
decisions remain in the native workflow.

For a CTA decision in this advisory flow, the original requester can mention
Commander again in the same Slack thread with
`request: Final CTA: <chosen wording>`. After checking the signed event, run
`node examples/video-review.mjs finish DB WORKSPACE REVIEW_EVENT PRODUCER_PROPOSAL OPERATOR RESPONSE_EVENT "Final CTA: <chosen wording>"`.
The close records the exact choice and queues a reply under Commander’s bot
identity in one transaction. A different requester, thread, or choice cannot
close the review. Repeating a close sends no additional reply. This step
finalizes the text plan and invokes no model or production action.

## Software Factory

`bind-factory` registers an operator-owned General Commander deployment. `prepare-factory` presents the authorized request to the original Factory control API. Set up the owner-only sealed converter grant described in Software Factory's `docs/MCP-CONTROL.md`. Supply `KUJO_SOFTWARE_FACTORY`, `KUJO_FACTORY_CONTROL_GRANT` and `KUJO_FACTORY_MISSION_ROOT` only in the local operator process. This command has a prepare-only scope. The Factory operator can separately inspect or submit the frozen digest through native control with an explicit grant. Native release and verification remain in the Factory.

## Troubleshooting, upgrade and uninstall

Check `health`, `roster`, `replay` and `deliveries`. Repair a mismatch through the original platform installation or operator mapping. An ambiguous delivery or uncertain request requires manual reconciliation against provider or host receipts. Restart does not re-execute uncertain effects. Revoked or incompatible deployment selections fail without partially enrolling the selected team.

Stop connector processes before upgrading. Keep a private backup for rollback. V1 rejects unknown store versions. Revoke your connection or deployment with `revoke`, remove mappings with `unmap`, and uninstall this app through its platform's admin interface. Existing apps and shared catalog/package checkouts are managed separately.

[Protocol and SDK](docs/PROTOCOL.md) · [Security](docs/SECURITY.md) · [Release status](docs/RELEASE-READINESS.md)

The optional `install-catalog KUJO_CHECKOUT PREFIX BIN_DIRECTORY CATALOG_SHA` command runs the canonical ecosystem installer in dry-run mode. Explicit `--apply` runs that same installer and verifies the resulting catalog commit. Review its core and operating dependency plan first. Use `collection` and `collections` to manage local named selections.

A separate `submit-factory DB WORKSPACE EVENT OPERATOR EXACT_MISSION_SHA256` command uses the existing submit grant. It can consume model usage and must be run only by the authorized operator after reviewing the frozen mission. It projects bounded controller states and a linked release record when present. The ordinary Factory Floor continues to serve its native evidence.

## Vercel Board

The experimental `./board` connector accepts an operator-configured `@vercel/board` SDK client. Bind an explicit Board root to a channel with `threads`, allow the exact native principal in `requestPrincipals`, and map that principal to an authorized workspace human. Configure agent deployment IDs and their Board profile names in `agents`. The SDK client should be scoped to read and reply only in the bound channels.

Call `transport.request(root)` to stage a native root starting with `request: ` through `core.inbound`. Local admission remains a separate operator action. Call `core.deliver` to send queued replies from the configured profiles with Board’s stable write identifier. Replies disable native sync and neutralize untrusted mentions. Mirrored messages, agent-profile authors, and unbound roots are excluded from request intake. Ambiguous writes remain in the delivery journal for operator inspection. The connector passed with the official local backend and on hosted Board with live GPT and Hermes replies. See the scope and remaining limits in the release status.

Teams is an SDK-hosted fixture adapter. Paperclip has a scoped read-only observer. Workspace-fixed MCP stdio exposes only roster and delivery status. See [qualification and gaps](docs/RELEASE-READINESS.md).
