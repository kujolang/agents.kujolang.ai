import {readFileSync, realpathSync, statSync} from 'node:fs';
import {join, resolve, sep} from 'node:path';
import {digest, id, requireValue} from './protocol.mjs';

const platforms = ['local','slack','matrix','teams','paperclip','board','mcp'];
export function loadCatalog(directory) {
  const base = realpathSync(directory);
  function json(relative, limit) {
    const path = realpathSync(resolve(base, relative));
    requireValue(path.startsWith(base + sep) && statSync(path).isFile() && statSync(path).size <= limit, 'unsafe-catalog');
    return JSON.parse(readFileSync(path, 'utf8'));
  }
  const registry = json('agent-registry.json', 256000);
  requireValue(registry.schema === 'kujo.agent.registry/v1' && Array.isArray(registry.agents)
    && registry.agents.length <= 500 && registry.agent_count === registry.agents.length, 'unsupported-catalog');
  const agents = new Map();
  for (const entry of registry.agents) {
    const definition = id(entry.id);
    requireValue(!agents.has(definition) && typeof entry.path === 'string'
      && !entry.path.split('/').includes('..'), 'invalid-catalog-entry');
    const manifest = json(join(entry.path, 'manifest.json'), 64_000);
    requireValue(manifest.id === definition && Array.isArray(manifest.capabilities?.required)
      && typeof manifest.version === 'string', 'profile-mismatch');
    agents.set(definition, {id:definition, name:entry.name, team:id(entry.package), version:manifest.version,
      required:manifest.capabilities.required.map(id)});
  }
  return [...agents.values()];
}

export function plan({platform, catalog, host, agents = [], teams = [], all = false}) {
  requireValue(platforms.includes(platform), 'invalid-platform');
  const supported = ['local','slack','matrix'].includes(platform);
  const selected = catalog.filter(agent => all || agents.includes(agent.id) || teams.includes(agent.team));
  requireValue(agents.every(key => selected.some(agent => agent.id === key))
    && teams.every(team => selected.some(agent => agent.team === team)), 'unknown-selection');
  const choices = selected.map(agent => {
    const missing = agent.required.filter(capability => !host.features.includes(capability));
    return {...agent, missing, available:supported && host.profiles.includes(agent.id) && missing.length === 0};
  });
  return {schema:'kujo.collaboration.plan/v1', platform, maturity:platform === 'local' ? 'local'
    : supported ? 'fixture-only' : 'unsupported',
  host:id(host.id), choices, install:[
    {command:'bash install.sh --group operating', purpose:'Install the canonical agent catalog, skills and workflow sources if missing.'},
    {command:'kennel validate', purpose:'Validate an existing owned project. Use kennel install for approved missing project dependencies.'},
  ], permissions:['enroll selected deployments', 'map verified platform accounts', 'stage authorized requests']};
}

export function enrollPlan(core, workspace, reviewed, host, namespace = 'default') {
  requireValue(reviewed.maturity !== 'unsupported' && reviewed.host === host.id
    && reviewed.choices.length > 0 && reviewed.choices.every(choice => choice.available
      && host.profiles.includes(choice.id) && choice.required.every(capability => host.features.includes(capability))),
  'plan-not-installable');
  return core.agents(workspace, reviewed.choices.map(choice => ({
    id:'agent-' + digest([workspace,host.id,id(namespace),choice.id]).slice(0,24),
    definitionId:choice.id, hostId:host.id, capabilities:host.operations,
    operations:host.outbound?.[choice.id] ?? [],
  })));
}
